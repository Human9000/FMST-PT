
import os
import pickle

import SimpleITK as sitk
import numpy as np
from sklearn.model_selection import KFold
from tqdm import tqdm


class Analysis:
    def __init__(self, train_root, test_root, conf_path="data_conf.pkl"):
        self.src_tr = train_root
        self.src_te = test_root
        self.conf_path = conf_path

    def analysis_data(self):
        assert not os.path.isfile(
            self.conf_path), f'file "{self.conf_path}" already exists!!!'

        # 获取所有文件名
        trs, tes = self.get_file_path()

        # 处理数据
        distribution = []
        print('...分析数据分布...')
        for ct, seg in tqdm(trs):
            mi, di = self.distribute_data(ct, seg)
            distribution.extend([mi - di, mi + di])  # 用两个数代表其分布

        print('...生成5折交叉验证...')
        kf = KFold(n_splits=5, shuffle=True, random_state=2022)

        data_conf = {
            'mean': np.mean(distribution),
            'std': np.std(distribution),
            'kfold': [{
                'train': trs[tr],
                'val': trs[val]} for tr, val in kf.split(trs)],
            'test': tes,
        }

        with open(self.conf_path, 'wb') as fp:
            pickle.dump(data_conf, fp)

        return data_conf

    def distribute_data(self, ct_path, seg_path):
        ct = sitk.ReadImage(ct_path)
        seg = sitk.ReadImage(seg_path)

        ct_arr = sitk.GetArrayFromImage(ct)
        seg_array = sitk.GetArrayFromImage(seg)

        iou_data = ct_arr[seg_array > 0]

        mi = np.mean(iou_data)
        di = np.std(iou_data)

        return mi, di

    def get_file_path(self):
        tr_files = os.listdir(self.src_tr)
        te_files = os.listdir(self.src_te)
        trs = []
        tes = []

        # 划分原数据和标签
        for file in tr_files:
            if file.startswith('volume'):
                seg = file.replace('volume', 'segmentation')
                assert seg in tr_files, f'seg:{seg} not in dir:{self.src_tr}'
                trs.append((os.path.join(self.src_tr, file),
                            os.path.join(self.src_tr, seg)))

        # 划分原数据和标签
        for file in te_files:
            if file.startswith('test-volume'):
                tes.append(os.path.join(self.src_tr, file))

        return np.array(trs), np.array(tes)


if __name__ == '__main__':
    tool = Analysis(train_root='/media/wgh/w2/data/LITS2017/Training',
                    test_root='/media/wgh/w1/data/LITS2017/Test_Data/')

    tool.analysis_data()
