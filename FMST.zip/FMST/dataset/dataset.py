import os
import pickle


import numpy as np
import torch
import torch.nn.functional as F
from scipy.stats import norm
from torch.utils.data import Dataset, DataLoader
from dataset.analysis import Analysis
import SimpleITK as sitk
from tqdm import tqdm


DEBUG = False

class Spectrum():
    def __init__(self, mean, std) -> None:
        self.mean = mean
        self.std = std

    def func(self, x):
        # [1%, 93%] 置信度
        l = norm.ppf(0.01) * self.std + self.mean
        r = norm.isf(0.05) * self.std + self.mean

        x[x < l] = l - 0.05 * self.std
        x[x > r] = r + 0.05 * self.std

        # print(l, r)
        return (x - self.mean) / self.std

    def func3lable(self, x):
        # [1%, 93%] 置信度
        l = norm.ppf(0.01) * self.std + self.mean
        r = norm.isf(0.5) * self.std + self.mean

        y = np.ones(x.shape)
        y[x < l] = 0
        y[x > r] = 2

        # print(l, r)

        return y


class CTDataset(Dataset):
    def __init__(self,
                 data_paths=[],
                 spectrum=None,
                 transforms=None,
                 interpolate=None,
                 BOOXCUT=False,
                 ATTX=False,
                 ATTY=False,
                 SEGX=False,
                 DIRECTION=True,
                 ):
        if DEBUG:
            self.data_paths = data_paths[:1]
        else:
            self.data_paths = data_paths
            
        self.transforms = transforms
        self.interpolate = interpolate
        self.spectrum = spectrum

        self.BOOXCUT = BOOXCUT
        self.ATTX = ATTX
        self.ATTY = ATTY
        self.SEGX = SEGX
        self.DIRECTION = DIRECTION

        self.LOG = False

        self.device = torch.device('cuda')
        self.dataset = self.__data_preload__()

    def __len__(self):
        return len(self.data_paths)

    def readFile(self, data_path):  # 读数据文件
        ct_path, seg_path = data_path

        ct = sitk.ReadImage(ct_path)
        seg = sitk.ReadImage(seg_path)

        ct_arr = sitk.GetArrayFromImage(ct)
        seg_arr = 1.0 * (sitk.GetArrayFromImage(seg) != 0)
        if self.DIRECTION:  # 方向对齐，较为耗时
            self.LOG and print('DIRECTION start')
            ct_arr, seg_arr = self.normal_direction(
                ct.GetDirection(), ct_arr, seg_arr)

        return ct_arr, seg_arr

    def __data_load_one__(self, index):
        self.LOG and print('readFile start')
        ct, seg = self.readFile(self.data_paths[index])

        if self.spectrum:  # 频谱共识
            self.LOG and print('spectrum start')
            ct = self.spectrum(ct)
            # print("频谱共识", ct.shape)

        if self.BOOXCUT:  # 剪裁位置框
            self.LOG and print('BOOXCUT start')
            ct, seg = self.bbox_cut(ct, seg)
            # print("剪裁位置框", ct.shape)

        # 扩充 batch, chanle
        ct = torch.FloatTensor(ct).unsqueeze(0).unsqueeze(0).to(self.device)
        seg = torch.FloatTensor(seg).unsqueeze(0).unsqueeze(0).to(self.device)

        if self.interpolate:  # 重采样
            self.LOG and print('interpolate start')
            ct = F.interpolate(ct, size=self.interpolate)
            seg = F.interpolate(seg, size=self.interpolate)

        if self.ATTX or self.ATTY:  # 注意力作为输入
            self.LOG and print('ATTX start')
            att = self.getAtt(seg).cpu()
        else:
            att = None

        if self.SEGX:
            self.LOG and print('SEGX start')
            small_seg = self.getSmallSeg(seg).cpu()
        else:
            small_seg = None
        ct, seg = ct.cpu(), seg.cpu()
        torch.cuda.empty_cache()
        return ct, seg, att, small_seg

    def __data_preload__(self):
        dataset = []
        print('=== 数据预加载 ===')
        for i in tqdm(range(len(self.data_paths))):
            dataset.append(self.__data_load_one__(i))
        return dataset

    def __getitem__(self, index):  # 0.9128 粗分割
        ct, seg, att, small_seg = self.dataset[index]

        if self.transforms:  # 数据扩充
            ct, seg, att, small_seg = self.transforms(ct, seg, att, small_seg)

        if self.ATTX:  # 注意力作为输入
            x = ct[0].to(self.device), att[0].to(self.device)
        elif self.SEGX:  # 粗分割作为输入
            x = ct[0].to(self.device), small_seg[0].to(self.device)
            # sitk.WriteImage(sitk.GetImageFromArray(ct[0,0].cpu()),'ct.nrrd')
            # sitk.WriteImage(sitk.GetImageFromArray(small_seg[0,0].cpu()),'small_seg.nrrd')
            seg = 1.0 * (seg - small_seg != 0)
        else:
            x = ct[0].to(self.device)

        if self.ATTY:  # 注意力作为输出
            y = torch.cat((1 - att, att), dim=1)[0].to(self.device)
        else:
            y = torch.cat((1 - seg, seg), dim=1)[0].to(self.device)

        return x, y

    def bbox_cut(self, ct, seg, r=2):
        index = np.where(seg > 0)

        pmin = np.min(index, axis=1)[-3:] - r
        pmax = np.max(index, axis=1)[-3:] + r + 1

        for i in range(len(pmax)):
            if pmax[i] > seg.shape[-3:][i]:
                pmax[i] = seg.shape[-3:][i]

        for i in range(len(pmin)):
            if pmin[i] < 0:
                pmin[i] = 0

        x0, y0, z0 = pmin
        x1, y1, z1, = pmax

        seg = seg[x0:x1, y0:y1, z0:z1]
        ct = ct[x0:x1, y0:y1, z0:z1]
        return ct, seg

    def getAtt(self, seg, r=2):
        # seg = seg.to(self.device)
        return 0.5 * F.avg_pool3d(seg, 2 * r + 1, stride=1, padding=r) + \
            0.3 * F.avg_pool3d(seg, 2 * 2 * r + 1, stride=1, padding=2*r) + \
            0.2 * F.avg_pool3d(seg, 2 * 3 * r + 1, stride=1, padding=3*r)

    def getSmallSeg(self, seg, r=1, step=2):
        # seg = seg.to(self.device)
        # sitk.WriteImage(sitk.GetImageFromArray(res), 'raweg.nrrd')
        for _ in range(step):
            seg = 1.0 * (0.5 < F.avg_pool3d(seg, 1 + 2 * r, stride=1, padding=r))
        for _ in range(step - 1):
            seg = F.max_pool3d(seg, 1 + 2 * r, stride=1, padding=r)
        # sitk.WriteImage(sitk.GetImageFromArray(res), 'samllseg.nrrd')
        # exit(0)
        return seg

    def normal_direction(self, direction, *arrs):
        d = list(int(i) for i in direction)  # CT方向对齐

        new_axes = []  # 新的维度
        new_aim = []  # 新的方向
        for index, value in enumerate(d):
            if value != 0:
                new_aim.append(value)
                new_axes.append(index % 3)

        for arr in arrs:
            arr = arr.transpose(new_axes)
            arr = arr[::new_aim[2], ::new_aim[1], ::new_aim[0]]

        return arrs


def makeDataset(
    train_root='/media/wgh/w2/data/LITS2017/Training',
    test_root='/media/wgh/w1/data/LITS2017/Test_Data/',
    data_conf_path="data_conf.pkl",  # 文件配置信息
    kfold=5,  # K 折交叉验证
    transforms=None,  # 数据扩充
    interpolate=None,  # 重采样大小
    BOOXCUT=False,  # 框剪切
    ATTX=False,  # 注意力做输入
    ATTY=False,  # 注意力做输出
    SEGX=False,  # 粗分割做输入
    DIRECTION=True,  # 方向调整
):
    if os.path.isfile(data_conf_path):  # 有没有数据配置结果
        print('===数据配置已存在,加载中===')
        with open(data_conf_path, 'rb') as fp:
            data_config = pickle.load(fp)
    else:  # 调用数据配置函数
        print('===缺少数据配置,创建中===')
        data_config = Analysis(train_root, test_root,
                               data_conf_path).analysis_data()

    tr_kfold = data_config['kfold'][kfold]['train']
    val_kfold = data_config['kfold'][kfold]['val']

    print(len(tr_kfold))
    print(len(val_kfold))
    print(data_config['mean'],
          data_config['std'],)
    tr_dataset = CTDataset(data_paths=tr_kfold,
                           spectrum=Spectrum(data_config['mean'],
                                             data_config['std'],
                                             ).func,
                           transforms=transforms,
                           interpolate=interpolate,
                           BOOXCUT=BOOXCUT,
                           ATTX=ATTX,
                           ATTY=ATTY,
                           SEGX=SEGX,
                           DIRECTION=DIRECTION,
                           )

    val_dataset = CTDataset(data_paths=val_kfold,
                            spectrum=Spectrum(data_config['mean'],
                                              data_config['std'],
                                              ).func,
                            transforms=None,
                            interpolate=interpolate,
                            BOOXCUT=BOOXCUT,
                            ATTX=ATTX,
                            ATTY=ATTY,
                            SEGX=SEGX,
                            DIRECTION=DIRECTION,
                            )

    return tr_dataset, val_dataset


def makeLoader(
    train_root='/media/wgh/w2/data/LITS2017/Training',
    test_root='/media/wgh/w1/data/LITS2017/Test_Data/',
    data_conf_path="data_conf.pkl",  # 文件配置信息
    kfold=5,  # K 折交叉验证
    transforms=None,  # 数据扩充
    interpolate=None,  # 重采样大小
    BOOXCUT=False,  # 框剪切
    ATTX=False,  # 注意力做输入
    ATTY=False,  # 注意力做输出
    SEGX=False,  # 粗分割做输入
    DIRECTION=True,  # 方向调整
):
    tr_dataset, val_dataset = makeDataset(
        train_root=train_root,
        test_root=test_root,
        data_conf_path=data_conf_path,
        kfold=kfold,
        transforms=transforms,
        interpolate=interpolate,
        BOOXCUT=BOOXCUT,
        ATTX=ATTX,
        ATTY=ATTY,
        SEGX=SEGX,
        DIRECTION=DIRECTION,  # 方向调整
    )
    tr_loader = DataLoader(dataset=tr_dataset, shuffle=True)  # 训练数据集读取器
    val_loader = DataLoader(dataset=val_dataset,  shuffle=False)  # 检验数据集读取器
    return tr_loader, val_loader
