import pickle
import json
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset
import SimpleITK as sitk
from tqdm import tqdm
from scipy.stats import norm

import os


class DataAnalysis():
    def __init__(self,
                 interpolate=(128, 128, 128),
                 ATTN=True,
                 data_conf='./lits2017.json',
                 data_pkl='./lits2017.pkl',
                 NEWPKL=True,
                 ) -> None:

        if NEWPKL is False and \
            data_pkl is not None and \
                os.path.isfile(data_pkl):
            print('Read pkl data {}'.format(data_pkl))
            with open(data_pkl, 'rb') as f:  # 反序列化
                self.info = pickle.load(f)
                self.interpolate = pickle.load(f)
                self.ATTN = pickle.load(f)
                self.device = pickle.load(f)
                self.dataset = pickle.load(f)
        else:
            print('\033[34;0mAnalysis data \033[0m')

            with open(data_conf, 'rb') as fp:
                info = json.load(fp)

            self.info = info
            self.interpolate = interpolate
            self.ATTN = ATTN
            self.device = torch.device('cpu')
            self.dataset = self.__data_preload__()

            print('Save pkl data {}'.format(data_pkl))
            with open(data_pkl, 'wb') as f:  # 序列化
                pickle.dump(self.info, f)
                pickle.dump(self.interpolate, f)
                pickle.dump(self.ATTN, f)
                pickle.dump(self.device, f)
                pickle.dump(self.dataset, f)

    def readTrainFile(self, img_path, lab_path):  # 读数据文件
        img = sitk.ReadImage(img_path)
        lab = sitk.ReadImage(lab_path)

        x = sitk.GetArrayFromImage(img)
        lab_arr = sitk.GetArrayFromImage(lab)

        y = np.zeros(lab_arr.shape, np.bool)
        for l in self.info['aim_label']:
            y[lab_arr == int(l)] = True

        # index = np.where(y)
        foreground = x[y]
        conf = {
            'name': img_path.split('/')[-1].split('.')[0],
            'mu': np.mean(foreground),
            'theta': np.std(foreground),
            'Direction': img.GetDirection(),
            'Spacing': img.GetSpacing(),
            'Origin': img.GetOrigin(),
            'Shape': x.shape,
        }

        # GPU 操作，torch.Tensor.GPU
        x = torch.FloatTensor(x).to(self.device).unsqueeze(0).unsqueeze(0)
        y = torch.FloatTensor(y).to(self.device).unsqueeze(0).unsqueeze(0)

        x = F.interpolate(x, size=self.interpolate)
        y = F.interpolate(y, size=self.interpolate)

        attn = F.interpolate(y, size=(32, 32, 32))
        attn = (attn + F.max_pool3d(attn, 3, 1, 1)) / 2
        attn = F.avg_pool3d(attn, 7, 1, 3)
        attn = F.interpolate(
            attn, size=y.shape[2:], mode='trilinear', align_corners=True)
        attn = (0.1 + attn) / 1.1
        # 返回 CPU，torch.Tensor.CPU
        x = x.cpu().squeeze(0).squeeze(0)
        y = y.cpu().squeeze(0).squeeze(0)
        attn = attn.cpu().squeeze(0).squeeze(0)
        torch.cuda.empty_cache()

        item = {
            'image': x,
            'label': y,
            'attn': attn,
            'conf': conf
        }

        return item

    def readTestFile(self, img_path):  # 读数据文件
        img = sitk.ReadImage(img_path)

        x = sitk.GetArrayFromImage(img)

        conf = {
            'name': img_path.split('/')[-1].split('.')[0],
            'mu': None,
            'theta': None,
            'Direction': img.GetDirection(),
            'Spacing': img.GetSpacing(),
            'Origin': img.GetOrigin(),
            'Shape': x.shape,
        }

        # GPU 操作，torch.Tensor.GPU
        x = torch.FloatTensor(x).to(self.device).unsqueeze(0).unsqueeze(0)
        x = F.interpolate(x, size=self.interpolate)
        # 返回 CPU，torch.Tensor.CPU
        x = x.cpu().squeeze(0).squeeze(0)
        torch.cuda.empty_cache()

        item = {
            'image': x,
            'label': None,
            'attn': None,
            'conf': conf
        }

        return item

    def __data_preload__(self):
        spectrum = []
        tr = []
        val = []
        te = []
        for path in tqdm(self.info['train'], desc='train', total=len(self.info['train'])):
            item = self.readTrainFile(path['image'], path['label'])
            mu, theta = item['conf']['mu'], item['conf']['theta']
            spectrum.extend([mu + theta, mu - theta])
            tr.append(item)

        for path in tqdm(self.info['valid'], desc='valid', total=len(self.info['valid'])):
            item = self.readTrainFile(path['image'], path['label'])
            mu, theta = item['conf']['mu'], item['conf']['theta']
            spectrum.extend([mu + theta, mu - theta])
            val.append(item)

        for path in tqdm(self.info['test'], desc='test', total=len(self.info['test'])):
            item = self.readTestFile(path)
            te.append(item)

        mu = np.mean(spectrum)
        theta = np.std(spectrum)

        # [1%, 99%] 置信度
        l = norm.ppf(0.01) * theta + mu
        r = norm.isf(0.01) * theta + mu

        for i in tr:
            i['image'] = (torch.clamp(i['image'], l, r) - mu) / theta
        for i in val:
            i['image'] = (torch.clamp(i['image'], l, r) - mu) / theta
        for i in te:
            i['image'] = (torch.clamp(i['image'], l, r) - mu) / theta

        dataset = {
            'train': tr,
            'valid': val,
            'test': te,
        }
        return dataset


class Dataset(Dataset):
    def __init__(self,
                 analysis: DataAnalysis = None,
                 data_type='train',  # 'train', 'valid', 'test'
                 transforms=None,
                 ):

        self.data_type = data_type
        self.transforms = transforms
        self.dataset = analysis.dataset[data_type]

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, index):
        item = self.dataset[index]
        if self.transforms:
            item = self.transforms(item)
        if  self.data_type == 'test':
            # 使用test数据集打开。 ----------------------------------------   
            if 'label' in item.keys() :
                del item['label']
            if 'mu' in item['conf'].keys() :
                del item['conf']['mu']
                del item['conf']['theta']
        return item


def main():
    analysis = DataAnalysis(interpolate=(128, 128, 128),
                            ATTN=True,
                            data_conf='dataset/lits2017.json',
                            data_pkl='/media/wgh/u2/lits2017.pkl'
                            )

    import transforms as T
    tr_dataset = Dataset(
        analysis,
        data_type='train',
        transforms=T.Compose(
            T.RandomCrop(slices=96),  # 随机裁剪96个切片
            T.RandomFlip(dims=[0, 1, 2]),  # 维度内依概率翻转默认50%概率
            T.RandomRotate(max_angle=180),  # 最后两个维度随机旋转[0-180°]
            T.RandomTranspose(dims=[0, 1, 2]),  # 依概率随机交换指定维度默认概率50%
            T.Mapping(0, 1),  # 数据最小值和最大值映射为[0-1]
        ))
    item = tr_dataset.__getitem__(0)
    print(item['image'])


if __name__ == '__main__':
    main()
