import os
import json
import pickle
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import SimpleITK as sitk
from scipy.stats import norm
from tqdm import tqdm


DEBUG = True
# filename_list = []
name_Nan = []
class DataAnalysis():
    def __init__(self,
                 interpolate=(128, 128, 128),
                 ATTN=True,
                 data_conf='./lits2017.json',
                 data_pkl='./lits2017.pkl',
                 NEWPKL=True,
                 ) -> None:

        if NEWPKL is False and \
            data_pkl is not None and \
                os.path.isfile(data_pkl):
            print('Read pkl data {}'.format(data_pkl))
            with open(data_pkl, 'rb') as f:  # 反序列化
                self.info = pickle.load(f)
                self.interpolate = pickle.load(f)
                self.ATTN = pickle.load(f)
                self.device = pickle.load(f)
                self.dataset = pickle.load(f)
        else:
            print('\033[34;0mAnalysis data \033[0m')

            with open(data_conf, 'rb') as fp:
                info = json.load(fp)

            self.info = info
            self.interpolate = interpolate
            self.ATTN = ATTN
            self.device = torch.device('cpu')
            self.dataset = self.__data_preload__()

            print('Save pkl data {}'.format(data_pkl))
            with open(data_pkl, 'wb') as f:  # 序列化
                pickle.dump(self.info, f)
                pickle.dump(self.interpolate, f)
                pickle.dump(self.ATTN, f)
                pickle.dump(self.device, f)
                pickle.dump(self.dataset, f)
    
    def readTrainFile(self, img_path, lab_path):  # 读数据文件
        # path_list0.append(img_path)
        # path_list1 = []
        # path_list2 = []
        # item_list = []
        # for filename in os.listdir(img_path):
        #     full_path = os.path.join(img_path, filename)
        #     if os.path.isfile(full_path):
        #     # if os.path.isdir(full_path):
        #         path_list1.append(full_path)
        #         # break

        # for filename in os.listdir(lab_path):
        #     full_path = os.path.join(lab_path, filename)
        #     if os.path.isfile(full_path):
        #     # if os.path.isdir(full_path):
        #         path_list2.append(full_path)
        #         # break

        # for img_path, lab_path in zip(path_list1, path_list2):
            # print(img)
            # print(lab)
        
        img = sitk.ReadImage(img_path)
        lab = sitk.ReadImage(lab_path)

        x = sitk.GetArrayFromImage(img)
        lab_arr = sitk.GetArrayFromImage(lab)
        # x_mean = x.mean()
        # lab_arr_mean = lab_arr.mean()
        # if (np.isnan(x_mean) or np.isnan(lab_arr_mean)):
        #     print(img_path.split('/')[-1].split('.')[0])
        y = np.zeros(lab_arr.shape, np.bool)
        for l in self.info['aim_label']:
            y[lab_arr == int(l)] = True
        
        
        # index = np.where(y)
        foreground = x[y]
        
        if (np.isnan(np.mean(foreground)) or np.isnan(np.std(foreground))):
            name_Nan.append(img_path.split('/')[-1].split('.')[0])
        conf = {
            'img_path': img_path,
            'label_path': lab_path,
            'aim_label': self.info['aim_label'],
            'name': img_path.split('/')[-1].split('.')[0],
            'mu': np.mean(foreground),
            'theta': np.std(foreground),
            'Direction': img.GetDirection(),
            'Spacing': img.GetSpacing(),
            'Origin': img.GetOrigin(),
            'Shape': x.shape,
            'name_Nan': name_Nan
        }

        # GPU 操作，torch.Tensor.GPU
        x = torch.FloatTensor(x).to(self.device).unsqueeze(0).unsqueeze(0)
        y = torch.FloatTensor(y).to(self.device).unsqueeze(0).unsqueeze(0)

        x = F.interpolate(x, size=self.interpolate)
        y = F.interpolate(y, size=self.interpolate)

        attn = F.interpolate(y, size=(32, 32, 32))
        attn = (attn + F.max_pool3d(attn, 3, 1, 1)) / 2
        attn = F.avg_pool3d(attn, 7, 1, 3)
        attn = F.interpolate(
            attn, size=y.shape[2:], mode='trilinear', align_corners=True)
        attn = (0.1 + attn) / 1.1
        # 返回 CPU，torch.Tensor.CPU
        # torch.Tensor.to()
        x = x.cpu().squeeze(0).squeeze(0) 
        y = y.cpu().squeeze(0).squeeze(0)
        # x = x.to(torch.float16).cpu().squeeze(0).squeeze(0) 
        # y = y.to(torch.uint8).cpu().squeeze(0).squeeze(0)
        attn = attn.cpu().squeeze(0).squeeze(0)
        torch.cuda.empty_cache()

        item = {
            'image': x,
            'label': y,
            'attn': attn,
            'conf': conf
        }
        # item_list.append(item)
        # break

        return item

    def readTestFile(self, img_path):  # 读数据文件
        # path_list1 = []
        # item_list = []
        # for filename in os.listdir(img_path):
        #     full_path = os.path.join(img_path, filename)
        #     if os.path.isfile(full_path):
        #     # if os.path.isdir(full_path):
        #         path_list1.append(full_path)
        #         # break


        # for img_path in path_list1:
        img = sitk.ReadImage(img_path)

        x = sitk.GetArrayFromImage(img)
        
        conf = {
            'name': img_path.split('/')[-1].split('.')[0],
            'mu': None,
            'theta': None,
            'Direction': img.GetDirection(),
            'Spacing': img.GetSpacing(),
            'Origin': img.GetOrigin(),
            'Shape': x.shape
        }

        # GPU 操作，torch.Tensor.GPU
        x = torch.FloatTensor(x).to(self.device).unsqueeze(0).unsqueeze(0)
        x = F.interpolate(x, size=self.interpolate)
        # 返回 CPU，torch.Tensor.CPU
        x = x.cpu().squeeze(0).squeeze(0)
        torch.cuda.empty_cache()

        item = {
            'image': x,
            'label': None,
            'attn': None,
            'conf': conf
        }
            # break
            # item_list.append(item)


        return item

    def __data_preload__(self):
        spectrum = []
        tr = []
        val = []
        te = []
        name_Nan = []
        # for path in tqdm(self.info['train'], desc='train', total=len(self.info['train'])):
        #     item = self.readTrainFile(path['image'], path['label'])
        #     # for item in item:
        #     mu, theta = item['conf']['mu'], item['conf']['theta']
        #     spectrum.extend([mu + theta, mu - theta])
        #     tr.append(item)
        
        for path in tqdm(self.info['train'], desc='train', total=len(self.info['train'])):
            filename_list1 = []
            filename_list2 = []
            for filename in os.listdir(path['image']):
                full_path = os.path.join(path['image'], filename)
                if os.path.isfile(full_path):
                # if os.path.isdir(full_path):
                    filename_list1.append(full_path)
                    # break
            for filename in os.listdir(path['label']):
                full_path = os.path.join(path['label'], filename)
                if os.path.isfile(full_path):
                # if os.path.isdir(full_path):
                    filename_list2.append(full_path)
                    # break
            filename_list1.sort()
            filename_list2.sort()
            for (filename_list1, filename_list2) in zip(filename_list1, filename_list2):

                item = self.readTrainFile(filename_list1, filename_list2)
                # item = self.readTrainFile(path['image'], path['label'])
                # for item in item:
                mu, theta = item['conf']['mu'], item['conf']['theta']
                
                if not (np.isnan(mu) or np.isnan(theta)):
                    spectrum.extend([mu + theta, mu - theta])
                # else:
                #     print(item['conf']['name'])
                #     name_Nan.append(item['conf']['name'])
                tr.append(item)
                # break
            # break

        for path in tqdm(self.info['valid'], desc='valid', total=len(self.info['valid'])):
            item = self.readTrainFile(path['image'], path['label'])
            # for item in item:
            mu, theta = item['conf']['mu'], item['conf']['theta']
            if not (np.isnan(mu) or np.isnan(theta)):
                spectrum.extend([mu + theta, mu - theta])
            # else:
            #     print(item['conf']['name'])
            #     name_Nan.append(item['conf']['name'])
            val.append(item)

        # for path in tqdm(self.info['valid'], desc='valid', total=len(self.info['valid'])):
        #     filename_list1 = []
        #     filename_list2 = []
        #     for filename in os.listdir(path['image']):
        #         full_path = os.path.join(path['image'], filename)
        #         if os.path.isfile(full_path):
        #         # if os.path.isdir(full_path):
        #             filename_list1.append(full_path)
        #             # break
        #     for filename in os.listdir(path['label']):
        #         full_path = os.path.join(path['label'], filename)
        #         if os.path.isfile(full_path):
        #         # if os.path.isdir(full_path):
        #             filename_list2.append(full_path)
        #             # break
        #     for (filename_list1, filename_list2) in zip(filename_list1, filename_list2):

        #         item = self.readTrainFile(filename_list1, filename_list2)
        #         # item = self.readTrainFile(path['image'], path['label'])
        #         # for item in item:
        #         mu, theta = item['conf']['mu'], item['conf']['theta']
        #         spectrum.extend([mu + theta, mu - theta])
        #         tr.append(item)
        #         break
        #     break
        
        for path in tqdm(self.info['test'], desc='test', total=len(self.info['test'])):
            # if os.path.isdir(full_path):
            item = self.readTestFile(path)
            # item = self.readTestFile(path)
            # for item in item:
            te.append(item)
            
        # for path in tqdm(self.info['test'], desc='test', total=len(self.info['test'])):
        #     filename_list1 = []
        #     for filename in os.listdir(path):
        #         full_path = os.path.join(path, filename)
        #         if os.path.isfile(full_path):
        #         # if os.path.isdir(full_path):
        #             filename_list1.append(full_path)
        #             # break
        #     for filename_list1 in filename_list1:
        #         item = self.readTestFile(filename_list1)
        #         # item = self.readTestFile(path)
        #         # for item in item:
        #         te.append(item)
        #         # break
        #     # break
        mu = np.mean(spectrum)
        theta = np.std(spectrum)
        # item['conf']['name_Nan'] = name_Nan
        # [1%, 99%] 置信度
        l = norm.ppf(0.01) * theta + mu
        r = norm.isf(0.01) * theta + mu

        for i in tr:
            i['image'] = (torch.clamp(i['image'], l, r) - mu) / theta
            i['l'] = l
            i['r'] = r
            i['mu'] = mu
            i['theta'] = theta

        for i in val:
            i['image'] = (torch.clamp(i['image'], l, r) - mu) / theta
            
            i['l'] = l
            i['r'] = r
            i['mu'] = mu
            i['theta'] = theta
        for i in te:
            i['image'] = (torch.clamp(i['image'], l, r) - mu) / theta
            
            i['l'] = l
            i['r'] = r
            i['mu'] = mu
            i['theta'] = theta

        dataset = {
            'train': tr,
            'valid': val,
            'test': te,
            
        }
        return dataset


class CTDataset(Dataset):
    def __init__(self,
                 data_paths=[],
                 transforms=None,
                 interpolate=None,
                 BOOXCUT=False,
                 DIRECTION=True,
                 ):
        if DEBUG:
            self.data_paths = data_paths[:1]
        else:
            self.data_paths = data_paths
            
        self.transforms = transforms
        self.interpolate = interpolate
        self.BOOXCUT = BOOXCUT
        self.DIRECTION = DIRECTION

        self.LOG = False

        self.device = torch.device('cuda')
        self.dataset = self.__data_preload__()

    def __len__(self):
        return len(self.dataset)
    
    def readFile(self, data_path):  # 读数据文件
        for f_name in os.listdir(data_path['image']):
            
            ct = sitk.ReadImage(data_path['image']+'/'+f_name)
            seg = sitk.ReadImage(data_path['label']+'/label'+f_name[3:])

            ct_arr = sitk.GetArrayFromImage(ct)
            seg_arr = 1.0 * (6==sitk.GetArrayFromImage(seg)) # 6是肝脏
            
            conf = {
                'Direction':ct.GetDirection(),
                'Spacing':ct.GetSpacing(),
                'Origin':ct.GetOrigin(),
            }
            # print(ct_arr.shape)
            
            if self.DIRECTION:  # 方向对齐，较为耗时
                self.LOG and print('DIRECTION start')
                ct_arr, seg_arr = self.normal_direction(
                    ct.GetDirection(), ct_arr, seg_arr)
                
            yield ct_arr, seg_arr, conf

    def __data_load_one__(self, index):
        self.LOG and print('readFile start')
        for ct, seg, conf in self.readFile(self.data_paths[index]):
            
            if self.BOOXCUT:  # 剪裁位置框
                self.LOG and print('BOOXCUT start')
                ct, seg = self.bbox_cut(ct, seg)
            ct[ct<-125] = -125
            ct[ct>275] = 275
            ct = (ct + 125) / (275 + 125)
            # 扩充 batch, chanle
            ct = torch.FloatTensor(ct).unsqueeze(0).unsqueeze(0)
            seg = torch.FloatTensor(seg).unsqueeze(0).unsqueeze(0)

            # if self.interpolate:  # 重采样
            #     self.LOG and print('interpolate start')
            #     ct = F.interpolate(ct.to(self.device), size=self.interpolate)
            #     seg = F.interpolate(seg.to(self.device), size=self.interpolate)
            #     torch.cuda.empty_cache()
            ct, seg = ct.cpu(), seg.cpu()
            yield ct, seg, conf

    def __data_preload__(self):
        dataset = []
        print('=== 数据预加载 ===')
        for i in tqdm(range(len(self.data_paths))):
            for d in self.__data_load_one__(i):
                dataset.append(d)
                
                return dataset

    def __getitem__(self, index): 
        ct, seg, conf = self.dataset[index]

        if self.transforms:  # 数据扩充
            ct, seg = self.transforms(ct, seg)

        x = ct[0].to(self.device)

        # one-hot
        y = F.one_hot(seg[0].long()).transpose(0,-1).squeeze(-1).to(self.device)
        
        img = sitk.GetImageFromArray(x.cpu()[0])
        img.SetDirection(conf['Direction'])
        img.SetOrigin(conf['Origin'])
        img.SetSpacing(conf['Spacing'])
        sitk.WriteImage(img,'x.nii.gz')
        
        temp = torch.zeros(x.shape[1:]).to(self.device)
        
        for i in range(y.shape[0]):
            temp += i * y[i]
            
        img = sitk.GetImageFromArray(temp.cpu())
        img.SetDirection(conf['Direction'])
        img.SetOrigin(conf['Origin'])
        img.SetSpacing(conf['Spacing'])
        sitk.WriteImage(img,'y.nii.gz')
        exit(0)
        return x, y

    def bbox_cut(self, ct, seg, r=2):
        index = np.where(seg > 0)

        pmin = np.min(index, axis=1)[-3:] - r
        pmax = np.max(index, axis=1)[-3:] + r + 1

        for i in range(len(pmax)):
            if pmax[i] > seg.shape[-3:][i]:
                pmax[i] = seg.shape[-3:][i]

        for i in range(len(pmin)):
            if pmin[i] < 0:
                pmin[i] = 0

        x0, y0, z0 = pmin
        x1, y1, z1, = pmax

        seg = seg[x0:x1, y0:y1, z0:z1]
        ct = ct[x0:x1, y0:y1, z0:z1]
        return ct, seg

    def normal_direction(self, direction, *arrs):
        d = list(int(i) for i in direction)  # CT方向对齐

        new_axes = []  # 新的维度
        new_aim = []  # 新的方向
        for index, value in enumerate(d):
            if value != 0:
                new_aim.append(value)
                new_axes.append(index % 3)

        for arr in arrs:
            arr = arr.transpose(new_axes)
            arr = arr[::new_aim[2], ::new_aim[1], ::new_aim[0]]

        return arrs


def makeDataset(
    data_conf_path="dataset/synapse.json",  # 文件配置信息
    transforms=None,   # 数据扩充
    interpolate=None,  # 重采样大小
    BOOXCUT=False,     # 框剪切
    DIRECTION=True,    # 方向调整
):
    if os.path.isfile(data_conf_path):  # 有没有数据配置结果
        print('===数据配置存在,加载中===')
        with open(data_conf_path, 'rb') as fp:
            data_config = json.load(fp)
    else:  # 调用数据配置函数
        print('===缺少数据配置===')
        exit(0)

    tr = data_config['training']
    val = data_config['validation']
    class_num = len(data_config['labels']) 
    print('training   number:',len(tr))
    print('validation number:',len(val))
    print('class      number:',class_num)
    
    tr_dataset = CTDataset(data_paths=tr,
                           transforms=transforms,
                           interpolate=interpolate,
                           BOOXCUT=BOOXCUT,
                           DIRECTION=DIRECTION,
                           )

    val_dataset = CTDataset(data_paths=val,
                            transforms=None,
                            interpolate=interpolate,
                            BOOXCUT=BOOXCUT,
                            DIRECTION=DIRECTION,
                            )

    return tr_dataset, val_dataset


def makeLoader(
    data_conf_path="data_conf.pkl",  # 文件配置信息
    transforms=None,  # 数据扩充
    interpolate=None,  # 重采样大小
    BOOXCUT=False,  # 框剪切
    DIRECTION=True,  # 方向调整
):
    tr_dataset, val_dataset = makeDataset(
        data_conf_path=data_conf_path,
        transforms=transforms,
        interpolate=interpolate,
        BOOXCUT=BOOXCUT,
        DIRECTION=DIRECTION,  # 方向调整
    )
    tr_loader = DataLoader(dataset=tr_dataset, shuffle=True)  # 训练数据集读取器
    val_loader = DataLoader(dataset=val_dataset,  shuffle=False)  # 检验数据集读取器
    return tr_loader, val_loader
