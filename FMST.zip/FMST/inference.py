from model.fmst import SNet, AttnNet, EdgeNet
from dataset.lits2017 import Dataset
from dataset.synapse import DataAnalysis
from dataset import transforms as T
import nibabel as nib
import skimage.measure
from torch.utils.data import DataLoader
from tqdm import tqdm
import torch
from torch.nn import functional as F
import numpy as np
import SimpleITK as sitk
import scipy.ndimage as ndimage
device = torch.device('cuda')
# device = torch.device('cpu')


def consensus_conf():
    model = SNet().to(device)
    ckpt = torch.load('/media/main/data/FTSM/FMST-PT-GXX/save/consensus/best_model_pre_liver.pth',map_location=device)
    model.load_state_dict(ckpt['net'], strict=False)
    return model


consensus_model = consensus_conf()


def attention_conf():
    model = AttnNet().to(device)
    ckpt = torch.load('/media/main/data/FTSM/FMST-PT-GXX/save/attention/best_model_pre_liver.pth')
    model.load_state_dict(ckpt['net'], strict=False)
    return model


attention_model = attention_conf()
# attention_model = None


def edge_conf():
    model = EdgeNet().to(device)
    ckpt = torch.load('/media/main/data/FTSM/FMST-PT-GXX/save/edge/best_model_pre_liver.pth')
    model.load_state_dict(ckpt['net'], strict=False)
    return model


edge_model = edge_conf()
# edge_model = None


def inference_attn_window(item):
    consensus_model.eval()
    x = item['image']
    xin = x.unsqueeze(0).unsqueeze(0).to(device)
    with torch.no_grad():
        pre_y = consensus_model(xin)[0]  # 模型求解
    attn = F.interpolate(pre_y[:, 1:], size=(32, 32, 32))
    attn = (attn + F.max_pool3d(attn, 3, 1, 1)) / 2
    attn = F.avg_pool3d(attn, 7, 1, 3)
    attn = F.interpolate(attn, size=xin.shape[2:], mode='trilinear', align_corners=True)
    attn = (0.1 + attn) / 1.1
    attn = attn.cpu().squeeze(0).squeeze(0)
 
    y = F.interpolate(1-pre_y[:, 1:], size=(32, 32, 32))  # 背景重采样
    y = F.max_pool3d(y, 3, 1, 1)  # 背景最大池化
    y = F.max_pool3d(1-y, 5, 1, 2)  # 前景最大池化
    y = F.interpolate(y, size=xin.shape[2:],
                      mode='trilinear', align_corners=True)
    y = y.cpu().squeeze(0).squeeze(0)  # 返回 CPU，torch.Tensor.CPU


    try:
        image = pre_y.cpu().numpy()[0,1] > 0.1

        # 标记连通域
        labels = skimage.measure.label(image, background=0, connectivity=3)

        # 获取连通域属性
        # print(labels[:, :, :, -3:, :])
        props = skimage.measure.regionprops(labels)
        

        # 找出面积最大的连通域
        max_area = 0
        max_label = 0
        for prop in props:
            if prop.area > max_area:
                max_area = prop.area
                max_label = prop.label

        # 获取最大连通域的边框坐标
        bbox = props[max_label-1].bbox
        x0, y0, z0, x1, y1, z1 = bbox
        if bbox is not None:
            x0,y0,z0,x1,y1,z1 = bbox
            x0 -= 2
            y0 -= 2
            z0 -= 2
            x1 += 3
            y1 += 3
            z1 += 3

        if x0 < 0: x0 = 0
        if y0 < 0: y0 = 0
        if z0 < 0: z0 = 0

        if x1 > 128: x1 = 128
        if y1 > 128: y1 = 128
        if z1 > 128: z1 = 128
    except:

        if x0 < 0: x0 = 0
        if y0 < 0: y0 = 0
        if z0 < 0: z0 = 0

        if x1 > 128: x1 = 128
        if y1 > 128: y1 = 128
        if z1 > 128: z1 = 128

        # exit(0)
    return [x0, x1, y0, y1, z0, z1], attn


def inference_seg(item):
    attention_model.eval()
    x = item['image']
    attn = item['attn']
    xin = x.unsqueeze(0).unsqueeze(0).to(device)
    attn = attn.unsqueeze(0).unsqueeze(0).to(device)
    
    with torch.no_grad():
        pre_y = attention_model(xin, attn)[0]  # 模型求解
    return pre_y.squeeze(0)


def inference_edge(item):
    edge_model.eval()
    x = item['image'].unsqueeze(0).unsqueeze(0).to(device)
    seg = item['seg'].unsqueeze(0).to(device)
    # print(x.shape)
    with torch.no_grad():
        p_seg, p_border = edge_model(x, seg)

    return p_seg.squeeze(0)


def save(img3d, file_path):  # (1, 3, 128, 128, 128)
    import cv2 as cv
    from torch.nn import functional as F
    from einops import rearrange
    img3d = F.interpolate(img3d, size=(64, 64, 64))  # (1,3,64,64,64)
    img = rearrange(img3d, 'b c (d0 d1) w h -> b (d0 w) (d1 h) c', d0=8)
    img = img[0].cpu()
    img = (img - img.min())/(img.max()-img.min()) * 255
    img = img.detach().numpy()

    img = rearrange(img, '(d0 d1 w) (d2 d3 h) c ->(d0 w) (d2 h) c (d1 d3)',
                    d0=4, d1=2, d2=4, d3=2)[..., 0]  # (1, 8*64,8*64, 3)
    cv.imwrite(file_path, img)

def run():
    print("==="*33)
    # 数据集配置
    analysis = DataAnalysis(interpolate=(128, 128, 128),
                            ATTN=True,
                            data_conf='/media/main/data/FTSM/FMST-PT-GXX/dataset/synapse_strong.json',
                            data_pkl='/media/main/data/FTSM/FMST-PT-GXX/dataset/synapse_liver_strong.pkl',
                            NEWPKL=False,  # False:如果有pkl数据直接读取,True：生成新的pkl文件
                            )
    import time
    
    n = 0
    t0 = time.time()
    print("==="*33)
    # for data_type in ['train', 'valid', 'test']:
    for data_type in ['valid']:
        loader = DataLoader(Dataset(
            analysis,
            data_type=data_type,
            transforms=T.Compose(
                T.CopyTo(device),  # 复制到显卡上
                T.NormalDirection(),
                T.Mapping(0, 1),  # 数据最小值和最大值映射为[0-1]
                T.Consensus(),
                # T.CopyTo(device),  # 复制到显卡上
                # T.NormalDirection(),
                # T.Mapping(0, 1),  # 数据最小值和最大值映射为[0-1]
                T.Attention(),
                T.ReadCutImage(),
                T.CopyTo(device),  # 复制到显卡上
                # T.NormalDirection(),
                T.Mapping(0, 1),  # 数据最小值和最大值映射为[0-1]
                T.Edge(),
                T.AddDim(0),  # 添加通道维度
                T.OneHot2classs(),  # 通道维度做成onehot编码
            )), shuffle=False)
        
        
        for item in tqdm(loader,desc='| %-5s'% data_type,total=len(loader)):
            # res0 = item['seg'] # attn 分割结果
            res0 = item['edgeup'] # edge 分割结果
            window = item['window'] # 窗口坐标
            shape = item['conf']['Shape'] # 原始形状信息
            y = item['label']
            
            [x0,x1,y0,y1,z0,z1] = window
            
            window_size = (x1-x0, y1-y0, z1-z0)
            # 把 128 还原为 window size
            res = F.pad( 
                F.interpolate(res0, size=window_size, mode="trilinear", align_corners=True),    
                (z0, shape[-1] - z1,
                y0, shape[-2] - y1,
                x0 , shape[-3] - x1))
            # print(res.shape, shape)
            py = res[0, 1] > 0.5
            x = item['image128'].unsqueeze(0)
            y = item['label128'].unsqueeze(0)
            # 还原x，y,pre
            x =  F.interpolate(x , size=shape).squeeze(0).squeeze(0) # b c d w h
            y =  F.interpolate(y , size=shape).squeeze(0).squeeze(0) > 0.3
                         
            n += py.shape[0]
        


            print(x.shape, y.shape, py.shape, py.sum(), item['conf']['name'][0])


            pred_img = sitk.GetImageFromArray(py.to(torch.float32).cpu().detach().numpy())
            x = sitk.GetImageFromArray(x.to(torch.float32).cpu().detach().numpy())
            y = sitk.GetImageFromArray(y.to(torch.float32).cpu().detach().numpy())
            

            sitk.WriteImage(pred_img, f"/media/main/data/FTSM/FMST-PT-GXX/test/liver/pre/{item['conf']['name'][0]}_pre.nii.gz")
            sitk.WriteImage(x, f"/media/main/data/FTSM/FMST-PT-GXX/test/liver/x/{item['conf']['name'][0]}_x.nii.gz")
            sitk.WriteImage(y, f"/media/main/data/FTSM/FMST-PT-GXX/test/liver/y/{item['conf']['name'][0]}_y.nii.gz")
            
    t1 = time.time()
    print('==='*33)
    print('| CT number\t:', 200)
    print('| All slice\t:', n)
    print('| All time(s)\t:', t1-t0)
    print('| slice/time\t:', n / (t1-t0))
    print('| number/time\t:', 200 / (t1-t0))
    print('==='*33)
    


def main():
    run()


if __name__ == '__main__':
    main()
