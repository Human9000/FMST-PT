import torch
from torch import nn
from torch.nn import functional as F


class CBR(nn.Module):
    def __init__(self, inc, outc):
        super().__init__() 
        self.cbr = nn.Sequential(
            nn.Conv3d(inc, outc, kernel_size=3),
            nn.Conv3d(outc, outc, kernel_size=3),
            nn.BatchNorm3d(outc),
            nn.ReLU(inplace=True),
        )
    def forward(self, x):
        return self.cbr(x)


class Encode(nn.Module):
    def __init__(self, inc, outc):
        super().__init__() 
        self.conv = nn.Sequential(
            nn.MaxPool3d(2, 2),
            CBR(inc, outc)
        )
    def forward(self, x):
        return self.conv(x)


class FE(nn.Module):
    def __init__(self):
        super().__init__()
        self.ln1 = nn.Linear(64, 8)
        self.ln2 = nn.Linear(64, 8)
        self.ln3 = nn.Linear(64, 8)
        self.ln4 = nn.Linear(8**3, 2*3)
        
    def forward(self, x):
        b,c,s,h,w = x.shape
        x = F.interpolate(x, 64)
        x1 = self.ln1(x)
        x2 = self.ln2(x1.transpose(-1,-2))
        x3 = self.ln3(x2.transpose(-1,-3))
        x4 = self.ln4(x3.reshape(b, c, -1))
        y = x4 * torch.Tensor([s, s, h, h, w, w]).view(1, 1, -1)
        return y


class Decode(nn.Module):
    def __init__(self):
        super().__init__() 
        self.fe = FE() # 给出inc个框框
        
    def forward(self, x, y0=None):
        if y0 is not None:
            return self.fe(x) + y0
        else:
            return self.fe(x)


class OutBlock(nn.Module):
    def __init__(self, inc, outc):
        super().__init__() 
        self.linear = nn.Linear(inc*6, outc*6) # 给了inc个框框
        
    def forward(self, x):
        b = x.shape[0]
        y = self.linear(x.reshape(b, -1))
        return y.reshape(b, -1, 6)


class Aim(nn.Module):
    def __init__(self, inc, outc):
        super().__init__()
        self.inblock = CBR(inc, 32)
        self.ens = nn.ModuleList([
            Encode(32, 32),
            Encode(32, 32),
            Encode(32, 32),
            Encode(32, 32),
            Encode(32, 32)
        ])
        
        self.des = nn.ModuleList([
            Decode(),
            Decode(),
            Decode(),
            Decode(),
            Decode()
        ])
        
        self.outs = nn.ModuleList([
            OutBlock(32, outc),
            OutBlock(32, outc),
            OutBlock(32, outc),
            OutBlock(32, outc),
            OutBlock(32, outc)
        ])        
        
        
    def forward(self, x):
        inx = self.inblock(x)
        # 特征编码，提取不同尺度特征
        xen = [en(inx) for en in self.ens]
        
        # 特征解码，将不同尺度的特征转化为多个位置框
        xdes = [self.des[0](xen[0], y0=None)]
        for i, de in enumerate(self.des):
            if i==0:
                y0 = None
            else:
                y0 = xdes[-1]
            xdes.append(de(xen[i], y0))
        
        # 综合多个特征转化出最终的位置框
        os = [o(x) for o,x in zip(self.outs, xdes)]
        o = torch.mean(torch.stack(os, dim=-1), dim=-1)
        
        print(o.shape)
        return o


from ptflops import get_model_complexity_info  # 支持任意维度计算
if __name__ == '__main__':
    net = Aim(1, 1)
    
    flops, params = get_model_complexity_info(
        net, (1, 128, 128, 128), as_strings=True, print_per_layer_stat=True)