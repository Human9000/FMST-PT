from tkinter.tix import X_REGION
import torch
import torch.nn as nn
import torch.nn.functional as F


class SNet(nn.Module):
    def __init__(self, inc=1, outc=2, training=True):
        super(SNet, self).__init__()
        self.training = training

        self.encoders = nn.ModuleList([
            nn.Conv3d(inc, 32, 3, stride=1, padding=1),
            nn.Conv3d(32, 32, 3, stride=1, padding=1),
            nn.Conv3d(32, 32, 3, stride=1, padding=1),
            nn.Conv3d(32, 32, 3, stride=1, padding=1),
            nn.Conv3d(32, 64, 3, stride=1, padding=1),
        ])

        self.con = nn.Conv3d(64, 64, 3, stride=1, padding=1)
        
        self.decoders = nn.ModuleList([
            nn.Conv3d(64, 32, 3, stride=1, padding=1),
            nn.Conv3d(32, 32, 3, stride=1, padding=1),
            nn.Conv3d(32, 32, 3, stride=1, padding=1),
            nn.Conv3d(32, 32, 3, stride=1, padding=1),
            nn.Conv3d(32, 32, 3, stride=1, padding=1),
        ])
        self.maps = nn.ModuleList([
            nn.Sequential(nn.Conv3d(32, outc, 1, 1), nn.Softmax(dim=1)),
            nn.Sequential(nn.Conv3d(32, outc, 1, 1), nn.Softmax(dim=1)),
            nn.Sequential(nn.Conv3d(32, outc, 1, 1), nn.Softmax(dim=1)),
            nn.Sequential(nn.Conv3d(32, outc, 1, 1), nn.Softmax(dim=1)),
        ])
    def forward(self, x):
        ens = [x]  # e0，e1, e2 ,e3, e4
        for encoder in self.encoders:
            y = F.instance_norm(encoder(ens[-1]))
            ens.append(F.relu(F.max_pool3d(y, 2, 2)))

        des = [self.con(ens[-1])]  # d0，d1, d2 ,d3, d4 -> _ , e4, e3, e2, e1
        for i, decoder in enumerate(self.decoders):
            enx = ens[-1-i]
            dex = F.interpolate(des[-1], size=enx.shape[2:],
                                mode='trilinear', align_corners=True) 
            des.append(F.relu(F.instance_norm(decoder(enx + dex))))

        outs = []  # o1, o2, o3, o4 -> d4, d3, d2, d1 -> e1, e2, e3, e4
        for i, map in enumerate(self.maps):
            dex = des[-1-i]
            o = F.interpolate(map(dex), size=x.shape[2:],
                              mode='trilinear', align_corners=True)
            outs.append(o)

        return outs


class AttnNet(SNet):
    def __init__(self, inc=1, outc=2, training=True):
        super(AttnNet, self).__init__(inc, outc, training)

    def forward(self, x, attn):
        ens = [x]  # e0，e1, e2 ,e3, e4
        for encoder in self.encoders:
            ens.append(F.relu(F.max_pool3d(encoder(ens[-1]), 2, 2)))

        des = [self.con(ens[-1])]  # d0，d1, d2 ,d3, d4 -> _ , e4, e3, e2, e1
        for i, decoder in enumerate(self.decoders):
            enx = ens[-1-i]
            dex = F.interpolate(des[-1], size=enx.shape[2:], mode='trilinear', align_corners=True)
            attn_gat = F.interpolate(attn, size=enx.shape[2:], mode='trilinear', align_corners=True)
            des.append(F.relu(decoder(attn_gat * (enx + dex))))

        outs = []  # o1, o2, o3, o4 -> d4, d3, d2, d1 -> e1, e2, e3, e4
        for i, map in enumerate(self.maps):
            dex = des[-1-i]
            o = F.interpolate(map(dex), size=x.shape[2:],
                              mode='trilinear', align_corners=True)
            outs.append(o)

        return outs


class EdgeNet(SNet):
    def __init__(self, inc=1, outc=2, training=True):
        super(EdgeNet, self).__init__(inc, outc, training)
        self.training = training
        self.firsten = nn.Conv3d(inc+outc, 32, 1, 1)

        self.borderMap = nn.ModuleList([
            nn.Sequential(nn.Conv3d(32, outc, 1, 1), nn.Softmax(dim=1)),
            nn.Sequential(nn.Conv3d(32, outc, 1, 1), nn.Softmax(dim=1)),
            nn.Sequential(nn.Conv3d(32, outc, 1, 1), nn.Softmax(dim=1)),
            nn.Sequential(nn.Conv3d(32, outc, 1, 1), nn.Softmax(dim=1)),
        ])

        self.merge_seg = nn.Sequential(
            nn.Conv3d(outc*4+inc, outc, 1, 1), nn.Softmax(dim=1))
        self.merge_border = nn.Sequential(
            nn.Conv3d(outc*4+inc, outc, 1, 1), nn.Softmax(dim=1))

    def forward(self, x, seg):
        on_f = 0.1 + F.max_pool3d(seg[:, 1:] - seg[:, :1] + 1, 7, 1, 3) # 向外扩张
        in_f = 2 - F.max_pool3d(seg[:,:1] - seg[:, 1:] + 1, 5, 1, 2) # 向内收缩
        m = torch.mean(x[in_f > 0.5]) # 主体像素
        # inx = on_f * torch.clamp(m - torch.abs(x - m), 0, m) # 其它像素距离主体的反向距离 
        # inx =  (1 - in_f) * torch.clamp(m - torch.abs(x - m), 0, m) # 其它像素距离主体的反向距离 
        inx =  torch.clamp(m - torch.abs(x - m), 0, m) # 其它像素距离主体的反向距离 

        ens = [inx]
        for encoder in self.encoders:
            # if ens.__len__() == 1:  # 由于输入维度变了，替换第一层
            #     encoder = self.firsten
            y = F.instance_norm(encoder(ens[-1]))
            ens.append(F.relu(F.max_pool3d(y, 2, 2)))

        des = [self.con(ens[-1])]  # d0，d1, d2 ,d3, d4 -> _ , e4, e3, e2, e1
        for i, decoder in enumerate(self.decoders):
            enx = ens[-1-i]
            dex = F.interpolate(des[-1], size=enx.shape[2:],
                                mode='trilinear', align_corners=True)
            des.append(F.relu(F.instance_norm(decoder(enx + dex))))

        segs = [inx]  # o1, o2, o3, o4 -> d4, d3, d2, d1 -> e1, e2, e3, e4
        for i, map in enumerate(self.maps):
            dex = des[-1-i]
            o = F.interpolate(map(dex), size=x.shape[2:],
                              mode='trilinear', align_corners=True)
            segs.append(o)

        borders = [inx]
        for i, map in enumerate(self.borderMap):
            dex = des[-1 - i]
            o = F.interpolate(map(dex), size=x.shape[2:],
                              mode='trilinear', align_corners=True)
            borders.append(o)
        
        border = self.merge_border(torch.cat(borders, dim=1))
        seg = self.merge_seg(torch.cat(segs, dim=1)) # * (1 - border[:,1:])
        
        return seg, border 
