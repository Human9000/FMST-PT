from einops import rearrange, reduce, repeat
import torch
import torch.nn as nn
import torch.nn.functional as F


class UNetBaseConv(nn.Module):
    def __init__(self, in_c, out_c, kernal_size=3, stride=1, padding=1):
        super().__init__()
        self.conv1 = nn.Conv3d(in_c, out_c, kernal_size,
                               stride, padding, bias=False)

        # self.conv2 = nn.Conv3d(out_c, out_c, kernal_size,
        #                        stride, padding, groups=out_c, bias=False)

        # self.in1 = nn.InstanceNorm3d(out_c)
        # self.in2 = nn.InstanceNorm3d(out_c)
    def forward(self, x):
        c1 = self.conv1(x)
        # c2 = self.conv2(c1)
        return c1  # self.in1(c1) #+ self.in2(c2)


class UNet(nn.Module):
    def __init__(self, in_channel=1, out_channel=14, training=True):
        super(UNet, self).__init__()
        self.training = training
        self.encoder1 = nn.Conv3d(in_channel, 32, 3, stride=1, padding=1)  # b, 16, 10, 10
        self.encoder2 = nn.Conv3d(32, 64, 3, stride=1, padding=1)  # b, 8, 3, 3
        self.encoder3 = nn.Conv3d(64, 128, 3, stride=1, padding=1)
        self.encoder4 = nn.Conv3d(128, 256, 3, stride=1, padding=1)

        self.decoder2 = nn.Conv3d(
            256, 128, 3, stride=1, padding=1)  # b, 8, 15, 1
        self.decoder3 = nn.Conv3d(
            128, 64, 3, stride=1, padding=1)  # b, 1, 28, 28
        self.decoder4 = nn.Conv3d(64, 32, 3, stride=1, padding=1)
        self.decoder5 = nn.Conv3d(32, 2, 3, stride=1, padding=1)

        self.map4 = nn.Sequential(
            nn.Conv3d(2, out_channel, 1, 1),
            nn.Softmax(dim=1)
        )

        # 128*128 尺度下的映射
        self.map3 = nn.Sequential(
            nn.Conv3d(64, out_channel, 1, 1),
            nn.Upsample(scale_factor=(4, 4, 4),
                        mode='trilinear', align_corners=True),
            nn.Softmax(dim=1)
        )

        # 64*64 尺度下的映射
        self.map2 = nn.Sequential(
            nn.Conv3d(128, out_channel, 1, 1),
            nn.Upsample(scale_factor=(8, 8, 8),
                        mode='trilinear', align_corners=True),
            nn.Softmax(dim=1)
        )

        # 32*32 尺度下的映射
        self.map1 = nn.Sequential(
            nn.Conv3d(256, out_channel, 1, 1),
            nn.Upsample(scale_factor=(16, 16, 16),
                        mode='trilinear', align_corners=True),
            nn.Softmax(dim=1)
        )

        # 参数 2
        # self.encoder1 = UNetBaseConv(in_channel, 32)  # b, 16, 10, 10
        # self.encoder2 = UNetBaseConv(32, 64)  # b, 8, 3, 3
        # self.encoder3 = UNetBaseConv(64, 128)
        # self.encoder4 = UNetBaseConv(128, 256)

        # self.decoder2 = UNetBaseConv(256, 128)
        # self.decoder3 = UNetBaseConv(128, 64)       # b, 1, 28, 28
        # self.decoder4 = UNetBaseConv(64, 32)
        # self.decoder5 = UNetBaseConv(32, 32)

        # self.map4 = nn.Sequential(
        #     nn.Conv3d(32, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )

        # # 128*128 尺度下的映射
        # self.map3 = nn.Sequential(
        #     nn.Conv3d(64, out_channel, 1, 1),
        #     nn.Upsample(scale_factor=(4, 4, 4),
        #                 mode='trilinear', align_corners=True),
        #     nn.Softmax(dim=1)
        # )

        # # 64*64 尺度下的映射
        # self.map2 = nn.Sequential(
        #     nn.Conv3d(128, out_channel, 1, 1),
        #     nn.Upsample(scale_factor=(8, 8, 8),
        #                 mode='trilinear', align_corners=True),
        #     nn.Softmax(dim=1)
        # )

        # # 32*32 尺度下的映射
        # self.map1 = nn.Sequential(
        #     nn.Conv3d(256, out_channel, 1, 1),
        #     nn.Upsample(scale_factor=(16, 16, 16),
        #                 mode='trilinear', align_corners=True),
        #     nn.Softmax(dim=1)
        # )

    def forward(self, x):
        # print(x.shape)
        out = F.relu(F.max_pool3d(self.encoder1(x), 2, 2))
        t1 = out
        out = F.relu(F.max_pool3d(self.encoder2(out), 2, 2))
        t2 = out
        out = F.relu(F.max_pool3d(self.encoder3(out), 2, 2))
        t3 = out
        out = F.relu(F.max_pool3d(self.encoder4(out), 2, 2))
        # t4 = out
        # out = F.relu(F.max_pool3d(self.encoder5(out),2,2))

        # t2 = out
        # out = F.relu(F.interpolate(self.decoder1(out),scale_factor=(2,2,2),mode ='trilinear'))
        # print(out.shape,t4.shape)
        output1 = self.map1(out)
        out = F.relu(F.interpolate(self.decoder2(out), scale_factor=(
            2, 2, 2), mode='trilinear', align_corners=True))
        out = torch.add(out, t3)
        output2 = self.map2(out)
        out = F.relu(F.interpolate(self.decoder3(out), scale_factor=(
            2, 2, 2), mode='trilinear', align_corners=True))
        out = torch.add(out, t2)
        output3 = self.map3(out)
        out = F.relu(F.interpolate(self.decoder4(out), scale_factor=(
            2, 2, 2), mode='trilinear', align_corners=True))
        out = torch.add(out, t1)

        out = F.relu(F.interpolate(self.decoder5(out), scale_factor=(
            2, 2, 2), mode='trilinear', align_corners=True))
        output4 = self.map4(out)
        
        return output1, output2, output3, output4


class BaseConvBlock(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()

        self.conv1 = nn.Conv3d(in_c, out_c, kernel_size=3, stride=1, padding=1)

        self.conv2 = nn.Conv3d(in_c, out_c,
                               kernel_size=3,
                               stride=1,
                               padding=2,
                               dilation=2)

        self.conv3 = nn.Conv3d(in_c, out_c,
                               kernel_size=3,
                               stride=1,
                               padding=4,
                               dilation=4)

        self.conv4 = nn.Conv3d(in_c, out_c,
                               kernel_size=3,
                               stride=1,
                               padding=8,
                               dilation=8)

    def forward(self, x):
        # c1 = self.conv1(x)
        # c2 = self.conv2(c1)
        # (d w h) : 句子长度，(dt wt ht)：单词大小
        # d,w,h = c1.shape[-3:]
        # d,w,h = d//self.t, w//self.t, h//self.t
        # r1 = rearrange(c2, 'b c (dt d) (wt w) (ht h) -> (b d w h) c dt wt ht',
        #                d=d,w=w,h=h)
        # 深度可分离全局卷积
        # c3 = self.conv3(c2)
        # 形状还原
        # r2 = rearrange(c3, '(b d w h)  c dt wt ht -> b c (dt d) (wt w) (ht h)',
        #                d=d,w=w,h=h)
        y = self.conv4(x)/4 + self.conv3(x)/4 + \
            self.conv2(x)/4 + self.conv1(x)/4
        return y


class AttBlock(nn.Module):
    def __init__(self,
                 c,
                 patch=4):
        super().__init__()
        self.p = patch

        self.linerP = nn.Sequential(nn.Linear(patch**3, 3**3),
                                    nn.InstanceNorm1d(3**3),
                                    nn.Linear(3**3, patch**3))

        self.linerC = nn.Sequential(nn.Linear(c, 8),
                                    nn.InstanceNorm1d(8),
                                    nn.Linear(8, c))

        self.in3d = nn.InstanceNorm3d(c)

    def forward(self, x):
        # 参数定义
        old_size = x.shape[2:]
        p = self.p
        d = [(p - i % p) % p for i in old_size]
        pad = (d[2]//2, d[2]-d[2]//2, # pad 逆序 （最后一个维度前，最后一个维度后，
               d[1]//2, d[1]-d[1]//2, #           倒数2个维度前，倒数2个维度后
               d[0]//2, d[0]-d[0]//2) #           倒数3个维度前，倒数3个维度后

        # 计算数据
        pad_x = F.pad(x, pad=pad)

        # 降采样
        t = reduce(pad_x, 'b c (pd d) (pw w) (ph h) -> b c (pd pw ph)', 'mean',
                   pd=self.p, pw=self.p, ph=self.p) # b c (pxpxp)

        # 全连接
        tp = self.linerP(t) # b c (pxpxp)
        tc = self.linerC(tp.transpose(1, -1)) # b (pxpxp) c

        # 上采样
        # att = repeat(tc, ' b (pd pw ph) c -> b c (pd d) (pw w) (ph h)',
        #              pd=self.p, pw=self.p, ph=self.p,
        #              d=pad_x.shape[2]//p,
        #              w=pad_x.shape[3]//p,
        #              h=pad_x.shape[4]//p,
        #              )
        att = rearrange(tc, 'b (d w h) c -> b c d w h',
                        d=self.p, w=self.p, h=self.p)

        att = F.interpolate(att, size=pad_x.shape[2:],
                            mode='trilinear', align_corners=True)

        # 去pad,pad 逆序
        att = att[:, :,
                  pad[4]:pad[4] + old_size[0],
                  pad[2]:pad[2] + old_size[1],
                  pad[0]:pad[0] + old_size[2]]

        return  self.in3d(x) + att  # 亮的更亮，暗的更暗


class PassLayer(nn.Module):
    def __init__(self, *arg):
        super().__init__()
        
    def forward(self, x):
        return x
    
class Simple_UNet(nn.Module):
    def __init__(self,
                 in_c=1,
                 out_c=2,
                 training=True):

        super().__init__()
        self.training = training

        # 参数量 1
        # self.encoder1 = nn.Conv3d(in_channel, 8, 3, 1, 1)
        # self.encoder2 = nn.Conv3d(8, 16, 3, 1, 1)
        # self.encoder3 = nn.Conv3d(16, 32, 3, 1, 1)
        # self.encoder4 = nn.Conv3d(32, 64, 3, 1, 1)

        # self.encoder5 = nn.Conv3d(64, 64, 3, 1, 1)

        # self.decoder1 = nn.Conv3d(64, 32, 3, 1, 1)
        # self.decoder2 = nn.Conv3d(32, 16, 3, 1, 1)
        # self.decoder3 = nn.Conv3d(16, 8, 3, 1, 1)
        # self.decoder4 = nn.Conv3d(8, 4, 3, 1, 1)

        # self.unres4 = nn.Sequential(
        #     nn.Conv3d(4, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )

        # self.unres3 = nn.Sequential(
        #     nn.Conv3d(8, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )

        # self.unres2 = nn.Sequential(
        #     nn.Conv3d(16, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )

        # self.unres1 = nn.Sequential(
        #     nn.Conv3d(32, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )

        # 参数量 1.5
        # norm =  nn.InstanceNorm3d
        norm = PassLayer
        # act = nn.LeakyReLU
        act = nn.ReLU
        # act = PassLayer
        pool = nn.MaxPool3d
        # att = AttBlock
        att = PassLayer
        # self.attB32 = AttBlock(32, 4)  # 共享权重，注意力提取块 32
        # self.attB64 = AttBlock(64, 4)  # 共享权重，注意力提取块 64
        self.encoder1 = nn.Sequential(nn.Conv3d(in_c, 32, 3, 1, 1), pool(2,2), norm(16), att(32, 13), act())#, self.attB32)
        self.encoder2 = nn.Sequential(nn.Conv3d(32, 32, 3, 1, 1), pool(2,2), norm(16), att(32, 11), act())#, self.attB32)
        self.encoder3 = nn.Sequential(nn.Conv3d(32, 32, 3, 1, 1), pool(2,2), norm(32), att(32, 7), act())#, self.attB32)
        self.encoder4 = nn.Sequential(nn.Conv3d(32, 64, 3, 1, 1), pool(2,2), norm(64), att(64, 5), act())#, self.attB64)

        self.encoder5 = nn.Sequential(nn.Conv3d(64, 64, 3, 1, 1), norm(64), att(64, 3), act())#, self.attB64)

        self.decoder1 = nn.Sequential(nn.Conv3d(64, 32, 3, 1, 1), norm(32), att(32, 5), act())#, self.attB32)
        self.decoder2 = nn.Sequential(nn.Conv3d(32, 32, 3, 1, 1), norm(32), att(32, 5), act())#, self.attB32)
        self.decoder3 = nn.Sequential(nn.Conv3d(32, 32, 3, 1, 1), norm(32), att(32, 5), act())#, self.attB32)
        self.decoder4 = nn.Sequential(nn.Conv3d(32, 32, 3, 1, 1), norm(16), att(16, 5), act())#, self.attB32)

        self.unres4 = nn.Sequential(
            nn.Conv3d(32, out_c, 1, 1),
            nn.Softmax(dim=1)
        )

        self.unres3 = nn.Sequential(
            nn.Conv3d(32, out_c, 1, 1),
            nn.Softmax(dim=1)
        )

        self.unres2 = nn.Sequential(
            nn.Conv3d(32, out_c, 1, 1),
            nn.Softmax(dim=1)
        )

        self.unres1 = nn.Sequential(
            nn.Conv3d(32, out_c, 1, 1),
            nn.Softmax(dim=1)
        )

        # 参数量 2 * 1.5
        # self.encoder1 = nn.Sequential(
        #     nn.Conv3d(in_channel, 32, 3, 1, 1), nn.Conv3d(32, 32, 3, 1, 1))
        # self.encoder2 = nn.Sequential(
        #     nn.Conv3d(32, 32, 3, 1, 1), nn.Conv3d(32, 32, 3, 1, 1))
        # self.encoder3 = nn.Sequential(
        #     nn.Conv3d(32, 32, 3, 1, 1), nn.Conv3d(32, 32, 3, 1, 1))
        # self.encoder4 = nn.Sequential(
        #     nn.Conv3d(32, 64, 3, 1, 1), nn.Conv3d(64, 64, 3, 1, 1))

        # self.encoder5 = nn.Sequential(
        #     nn.Conv3d(64, 64, 3, 1, 1), nn.Conv3d(64, 64, 3, 1, 1))

        # self.decoder1 = nn.Sequential(
        #     nn.Conv3d(64, 32, 3, 1, 1), nn.Conv3d(32, 32, 3, 1, 1))
        # self.decoder2 = nn.Sequential(
        #     nn.Conv3d(32, 32, 3, 1, 1), nn.Conv3d(32, 32, 3, 1, 1))
        # self.decoder3 = nn.Sequential(
        #     nn.Conv3d(32, 32, 3, 1, 1), nn.Conv3d(32, 32, 3, 1, 1))
        # self.decoder4 = nn.Sequential(
        #     nn.Conv3d(32, 32, 3, 1, 1), nn.Conv3d(32, 32, 3, 1, 1))

        # self.unres4 = nn.Sequential(
        #     nn.Conv3d(32, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )

        # self.unres3 = nn.Sequential(
        #     nn.Conv3d(32, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )

        # self.unres2 = nn.Sequential(
        #     nn.Conv3d(32, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )
        # self.unres1 = nn.Sequential(
        #     nn.Conv3d(32, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )

        # 参数量 2
        # self.encoder1 = nn.Conv3d(in_channel, 32, 3, 1, 1)
        # self.encoder2 = nn.Conv3d(32, 64, 3, 1, 1)
        # self.encoder3 = nn.Conv3d(64, 128, 3, 1, 1)
        # self.encoder4 = nn.Conv3d(128, 256, 3, 1, 1)

        # self.encoder5 = nn.Conv3d(256, 256, 3, 1, 1)

        # self.decoder1 = nn.Conv3d(256, 128, 3, 1, 1)
        # self.decoder2 = nn.Conv3d(128, 64, 3, 1, 1)
        # self.decoder3 = nn.Conv3d(64, 32, 3, 1, 1)
        # self.decoder4 = nn.Conv3d(32, 16, 3, 1, 1)

        # self.unres4 = nn.Sequential(
        #     nn.Conv3d(16, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )

        # self.unres3 = nn.Sequential(
        #     nn.Conv3d(32, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )

        # self.unres2 = nn.Sequential(
        #     nn.Conv3d(64, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )
        # self.unres1 = nn.Sequential(
        #     nn.Conv3d(128, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )
        
    def forward(self, x):
        down1 =self.encoder1(x)
        down2 = self.encoder2(down1)
        down3 = self.encoder3(down2)
        down4 = self.encoder4(down3)
        down5 = self.encoder5(down4)

        t = down5 + down4
        up1 = F.relu(F.interpolate(self.decoder1(
            t), size=down3.shape[-3:], mode='trilinear', align_corners=True))

        t = up1 + down3
        up2 = F.leaky_relu(F.interpolate(self.decoder2(
            t), size=down2.shape[-3:], mode='trilinear', align_corners=True))

        t = up2 + down2
        up3 = F.leaky_relu(F.interpolate(self.decoder3(
            t), size=down1.shape[-3:], mode='trilinear', align_corners=True))

        t = up3 + down1
        up4 = F.relu(F.interpolate(self.decoder4(
            t),  size=x.shape[-3:], mode='trilinear', align_corners=True))

        return [   F.interpolate(self.unres4(up4), size=x.shape[-3:]),
            F.interpolate(self.unres3(up3), size=x.shape[-3:]),
            F.interpolate(self.unres2(up2), size=x.shape[-3:]),
            F.interpolate(self.unres1(up1), size=x.shape[-3:])
            ]


class Attension_Simple_UNet(nn.Module):
    def __init__(self,
                 in_channel=1,
                 out_channel=2,
                 training=True):

        super().__init__()
        self.training = training

        self.encoder1 = nn.Conv3d(in_channel, 8, 3, 1, 1)
        self.encoder2 = nn.Conv3d(8, 16, 3, 1, 1)
        self.encoder3 = nn.Conv3d(16, 32, 3, 1, 1)
        self.encoder4 = nn.Conv3d(32, 64, 3, 1, 1)

        self.encoder5 = nn.Conv3d(64, 64, 3, 1, 1)

        self.decoder1 = nn.Conv3d(64, 32, 3, 1, 1)
        self.decoder2 = nn.Conv3d(32, 16, 3, 1, 1)
        self.decoder3 = nn.Conv3d(16, 8, 3, 1, 1)
        self.decoder4 = nn.Conv3d(8, 4, 3, 1, 1)

        self.unres4 = nn.Sequential(
            nn.Conv3d(4, out_channel, 1, 1),
            nn.Softmax(dim=1)
        )

        self.unres3 = nn.Sequential(
            nn.Conv3d(8, out_channel, 1, 1),
            nn.Softmax(dim=1)
        )

        self.unres2 = nn.Sequential(
            nn.Conv3d(16, out_channel, 1, 1),
            nn.Softmax(dim=1)
        )
        self.unres1 = nn.Sequential(
            nn.Conv3d(32, out_channel, 1, 1),
            nn.Softmax(dim=1)
        )

    def forward(self, xatt):
        x, att = xatt
        down1 = F.leaky_relu(F.max_pool3d(self.encoder1(x), 2, 2))
        down2 = F.leaky_relu(F.max_pool3d(self.encoder2(down1), 2, 2))
        down3 = F.leaky_relu(F.max_pool3d(self.encoder3(down2), 2, 2))
        down4 = F.leaky_relu(F.max_pool3d(self.encoder4(down3), 2, 2))
        down5 = F.leaky_relu(self.encoder5(down4), 2, 2)

        t = (down5 + down4) * F.interpolate(att, size=down4.shape[-3:])
        up1 = F.relu(F.interpolate(self.decoder1(t), size=down3.shape[-3:]))

        t = (up1 + down3) * F.interpolate(att, size=down3.shape[-3:])
        up2 = F.relu(F.interpolate(self.decoder2(t), size=down2.shape[-3:]))

        t = (up2 + down2) * F.interpolate(att, size=down2.shape[-3:])
        up3 = F.relu(F.interpolate(self.decoder3(t), size=down1.shape[-3:]))

        t = (up3 + down1) * F.interpolate(att, size=down1.shape[-3:])
        up4 = F.relu(F.interpolate(self.decoder4(t), size=x.shape[-3:]))

        if self.training is True:  # 从高分辨率依次降低
            return [F.interpolate(self.unres4(up4), size=x.shape[-3:]),
                    F.interpolate(self.unres3(up3), size=x.shape[-3:]),
                    F.interpolate(self.unres2(up2), size=x.shape[-3:]),
                    F.interpolate(self.unres1(up1), size=x.shape[-3:])]
        else:
            return self.unres4(up4)


class Edge_UNet(nn.Module):
    def __init__(self,
                 in_channel=1,
                 out_channel=2,
                 training=True):

        super().__init__()
        self.training = training
        # self.encoder1 = nn.Conv3d(in_channel, 4, 3, 1, 2, 2)
        # self.encoder2 = nn.Conv3d(4, 8, 3, 1, 2, 2)
        # self.encoder3 = nn.Conv3d(8, 16, 3, 1, 2, 2)

        # self.decoder0 = nn.Conv3d(1, 16, 3, 1, 2, 2)

        # self.decoder1 = nn.Conv3d(16, 8, 3, 1, 2, 2)
        # self.decoder2 = nn.Conv3d(8, 4, 3, 1, 2, 2)
        # self.decoder3 = nn.Conv3d(4, 1, 3, 1, 2, 2)

        # self.unres3 = nn.Sequential(
        #     nn.Conv3d(1, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )

        # self.unres2 = nn.Sequential(
        #     nn.Conv3d(4, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )

        # self.unres1 = nn.Sequential(
        #     nn.Conv3d(8, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )

        # self.unres0 = nn.Sequential(
        #     nn.Conv3d(16, out_channel, 1, 1),
        #     nn.Softmax(dim=1)
        # )

        # self.conv1 = nn.Sequential(nn.Conv3d(1, out_channel, 3, 1, 1),  nn.Softmax(dim=1))
        self.c1 = nn.Conv3d(in_channel, 16, 3, 1, 1)
        self.c2 = nn.Conv3d(16, 16, 3, 1, 1, groups=16)
        self.c3 = nn.Conv3d(16, 16, 3, 1, 1, groups=16)
        self.c4 = nn.Conv3d(16, 16, 3, 1, 1, groups=16)
        self.c5 = nn.Conv3d(16, out_channel, 3, 1, 1)
        self.conv2 = nn.Sequential(self.c1,
                                   self.c2,
                                   self.c3,
                                   self.c4,
                                   self.c5,
                                   nn.ReLU(),
                                   nn.Softmax(dim=1))
        # self.c.weight.data = torch.ones(self.c.weight.data.shape)*1

    def forward(self, x_seg):
        x, seg = x_seg
        # print(x.shape)
        # down1 = F.leaky_relu(self.encoder1(x))
        # # print(down1.shape)
        # down2 = F.leaky_relu(self.encoder2(down1))
        # # print(down2.shape)
        # down3 = F.leaky_relu(self.encoder3(down2))
        # # print(down3.shape)

        # up0 = F.leaky_relu(self.decoder0(seg))
        # # print(up0.shape)

        # # x = torch.cat((up0, down3), dim=1)
        # t = up0 + down3

        # up1 = F.relu(self.decoder1(t))

        # # x = torch.cat((up1, down2), dim=1)
        # t = up1 + down2
        # up2 = F.relu(self.decoder2(t))

        # # x = torch.cat((up2, down1), dim=1)
        # t = up2 + down1
        # up3 = F.relu(self.decoder3(t))

        # y = self.conv2(torch.cat((x, seg), dim=1))
        y = self.conv2(seg) - seg
        if self.training is True:  # 从高分辨率依次降低
            return [
                # self.unres3(up3),
                # F.interpolate(self.unres2(up2), size=x.shape[-3:]),
                # F.interpolate(self.unres1(up1), size=x.shape[-3:]),
                # F.interpolate(self.unres0(up0), size=x.shape[-3:]),
                # F.interpolate(self.unres0(up0), size=x.shape[-3:]),
                # torch.cat((1-seg,seg), dim=1),
                # self.conv1(x+seg),
                y, y, y, y
                # self.unres1(up1),
                # # self.unres3(seg),
                # self.unres0(up0),
                # self.conv1(x+seg),
                # self.conv2(torch.cat((x,seg),dim=1)),
                # self.unres0(up0),
                # self.unres0(up0),
                # self.unres0(up0),
            ]
        else:
            return y  # self.conv2(torch.cat((x,seg),dim=1)) #self.conv1(x+seg)#self.unres1(up1) # self.unres3(seg)# torch.cat((1-seg, seg),dim=1) # self.unres3(seg)#, self.unres3(seg), self.unres3(seg), self.unres3(seg)#,self.unres3(up3)


def main():

    # from torchstat import stat
    from torchsummary import summary
    from ptflops import get_model_complexity_info

    # device = torch.device('cuda:0')

    simple_unet = Simple_UNet()  # .to(device)

    print('simple_unet')
    # summary(simple_unet, (1, 128, 256, 256), batch_size=1, device='cpu')
    ops, params = get_model_complexity_info(simple_unet, (1, 128, 256, 256), as_strings=True,
                                            print_per_layer_stat=True, verbose=True)


if __name__ == '__main__':
    main()
