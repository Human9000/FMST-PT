
from torch import nn
import torch
from torch.nn import functional as F
from einops import rearrange, reduce, repeat


class Mask_1Chanle(nn.Module):  # 双向通道掩码
    def __init__(self, c):
        super().__init__()
        self.p = torch.nn.Parameter(
            torch.ones((1, c, 1, 1, 1)))  # (1, c, 1, 1)
        self.register_parameter("p", self.p)

        for i in range(0, c, 2):  # 设置
            self.p.data[0, i] = -1

    def forward(self, x):
        y = self.p * x
        return y


class ChanleBlock(nn.Module):
    def __init__(self, c_in, c_out) -> None:
        super().__init__()
        self.conva = nn.Conv3d(c_in, c_in, 1, bias=False)
        self.convb = nn.Conv3d(c_in, c_in, 1, bias=False)
        self.conv2 = nn.Conv3d(c_in, c_out, 1, bias=False)

        self.inN = nn.InstanceNorm3d(c_out)
        self.lrelu = nn.LeakyReLU()
        self.mask_c = Mask_1Chanle(c_out)
        # print(self)

    def forward(self, x):
        a = self.conva(x)
        b = self.convb(x)
        c = self.conv2(a * x + b)  # ax+b 计算结构
        m = self.mask_c(c)
        y = self.lrelu(self.inN(m))
        return y


class ConvFormer(nn.Module):
    def __init__(self,c_in,c_out):
        super().__init__()
        self.conv1 = nn.Sequential(nn.Conv3d(c_in, 1, 3, 1, 1), nn.Sigmoid())
        self.conv2 = nn.Sequential(nn.Conv3d(c_in, 1, 3, 1, 1), nn.Sigmoid())
        self.conv3 = nn.Sequential(nn.Conv3d(c_in, 1, 3, 1, 1), nn.Sigmoid())
        
        self.conv4 = nn.Conv3d(c_in, c_out, 3, 1, 1)

    def forward(self, x):
        b1 = self.conv1(x)
        b2 = self.conv2(x)
        b3 = self.conv3(x)
        b4 = self.conv4(x)

        # b c不变，d w h 填充为8的倍数
        _, _, d, w, h = size = b1.size()
        ad, aw, ah = self.adsize(size[-3:], 4)

        b1 = F.pad(b1, (0, ad, 0, aw, 0, ah))
        b2 = F.pad(b2, (0, ad, 0, aw, 0, ah))
        b3 = F.pad(b3, (0, ad, 0, aw, 0, ah))

        s0, s1, s2 = [i//4 for i in b1.shape[-3:]]

        # 固定单词大小，自适应句子长度  求出来 s0 s1 s2 个块, 每个块有 d w h 个字符构成
        b1 = reduce(
            b1, 'b c (s0 d) (s1 w) (s2 h) -> b c (s0 s1 s2)', 'mean', d=4, w=4, h=4)
        b2 = reduce(
            b2, 'b c (s0 d) (s1 w) (s2 h) -> b c (s0 s1 s2)', 'mean', d=4, w=4, h=4)
        b3 = reduce(
            b3, 'b c (s0 d) (s1 w) (s2 h) -> b c (s0 s1 s2)', 'mean', d=4, w=4, h=4)

        att = rearrange(b1 @ (b2.transpose(-1, -2)) @ b3 /(64**3),
                      'b c (s0 s1 s2) -> b c s0 s1 s2',
                      s0=s0, s1=s1, s2=s2)
        
        att = repeat(att,'b c s0 s1 s2-> b c (s0 d) (s1 w) (s2 h)',
                      d=4, w=4, h=4, s0=s0, s1=s1, s2=s2)[:, :, :d, :w, :h]
        
        att = F.sigmoid(att)
        # print(att.mean())
        
        return b4 #* att

    def adsize(self, old_size, d):
        return [(d - i % d) % d for i in old_size]


class FormerNet(nn.Module):
    def __init__(self,cin,cout,training):
        super().__init__()
        self.conv = nn.Sequential(
            ConvFormer(cin,4),
            # ConvFormer(4,4),
            # ConvFormer(4,4),
            ConvFormer(4,cout),
            ) 
        self.training = training


    def forward(self,x):
        y = self.conv(x)
        
        if self.training:
            return [y, y, y, y]
        else:
            return y


class ParallelConv(nn.Module):
    def __init__(self, c_in, c_out,
                 kernel_size=3,
                 stride=1,
                 n=3,  # 平行卷积核数据数量
                 d=1,  # 多尺度空洞长度x
                 DILATION=True
                 ):
        super().__init__()
        r = kernel_size//2  # 计算卷积半径
        self.d = d  # 获取空洞卷积的基础空洞长度
        # self.chanleblock = ChanleBlock(c_in, c_out)
        self.chanleblock = nn.Conv3d(c_in, c_out, 1)
        self.conv = nn.Conv3d(c_out, c_out, 3, 1, 1)
        self.n = n

        # 横向并行，x的n次方
        # self.conv_as = nn.ModuleList([
        #     nn.Conv3d(
        #         c_out, c_out,
        #         kernel_size=kernel_size,
        #         stride=stride,
        #         padding=r if not DILATION else d*i*r,
        #         dilation=1 if not DILATION else d*i,  # 是否采用空洞多尺度
        #         groups=c_out,
        #         bias=False,
        #     )
        #     for i in range(1, n+1)  # i=[1,....,n]
        # ])

        self.conv_bs = nn.ModuleList([
            nn.Conv3d(
                c_out, c_out,
                kernel_size=kernel_size,
                stride=stride,
                padding=r if not DILATION else d*i*r,
                dilation=1 if not DILATION else d*i,  # 是否采用空洞多尺度
                groups=c_out,
                bias=False,
            )
            for i in range(1, n+1)  # i=[1,....,n]
        ])

        # self.inN = nn.InstanceNorm3d(c_out)
        # self.activate = nn.ReLU()

    def forward(self, x):
        c = self.chanleblock(x)  # (b, c_in, w, h) -> (b, c_out, w, h)
        y = self.conv(c)  # (b, c_in, w, h) -> (b, c_out, w, h)
        # pas = [conv(y) for conv in self.conv_as][::-1]  # 从高
        # pbs = [conv(y) for conv in self.conv_bs][::-1]
        # for a, b in zip(pas, pbs):
        #     y = self.activate(self.inN(a * y + b))  # ax + b 计算结构

        for i in range(self.n):
            y = y + self.conv_bs[i](c)/self.n/2
        return y


class ParallelNet(nn.Module):
    def __init__(self, c_in, c_out, training=True):
        super().__init__()
        self.training = training

        self.convs = nn.Sequential(
            ParallelConv(c_in, 4),
            ParallelConv(4, 4),
            ParallelConv(4, 4),
            ParallelConv(4, c_out),
            nn.Softmax(dim=1),
        )

    def forward(self, x):
        y = self.convs(x)  # (b, c_in, w, h) -> (b, c_out, w, h)

        if self.training:
            return [y, y, y, y]
        else:
            return y


class Simple_UNet(nn.Module):
    def __init__(self,
                 in_channel=1,
                 out_channel=2,
                 training=True):

        super().__init__()
        self.training = training

        # 参数量 1.5
        self.encoder1 = ParallelConv(in_channel, 32)
        self.encoder2 = ParallelConv(32, 32)
        self.encoder3 = ParallelConv(32, 32)
        self.encoder4 = ParallelConv(32, 64)

        self.encoder5 = ParallelConv(64, 64)

        self.decoder1 = ParallelConv(64, 32)
        self.decoder2 = ParallelConv(32, 32)
        self.decoder3 = ParallelConv(32, 32)
        self.decoder4 = ParallelConv(32, 32)

        self.unres4 = nn.Sequential(
            nn.Conv3d(32, out_channel, 1, 1),
            nn.Softmax(dim=1)
        )

        self.unres3 = nn.Sequential(
            nn.Conv3d(32, out_channel, 1, 1),
            nn.Softmax(dim=1)
        )

        self.unres2 = nn.Sequential(
            nn.Conv3d(32, out_channel, 1, 1),
            nn.Softmax(dim=1)
        )
        self.unres1 = nn.Sequential(
            nn.Conv3d(32, out_channel, 1, 1),
            nn.Softmax(dim=1)
        )

    def forward(self, x):
        down1 = F.leaky_relu(F.max_pool3d(self.encoder1(x), 2, 2))
        down2 = F.leaky_relu(F.max_pool3d(self.encoder2(down1), 2, 2))
        down3 = F.leaky_relu(F.max_pool3d(self.encoder3(down2), 2, 2))
        down4 = F.leaky_relu(F.max_pool3d(self.encoder4(down3), 2, 2))

        down5 = F.leaky_relu(self.encoder5(down4))

        t = down5 + down4
        up1 = F.relu(F.interpolate(self.decoder1(
            t), size=down3.shape[-3:], mode='trilinear', align_corners=True))

        t = up1 + down3
        up2 = F.leaky_relu(F.interpolate(self.decoder2(
            t), size=down2.shape[-3:], mode='trilinear', align_corners=True))

        t = up2 + down2
        up3 = F.leaky_relu(F.interpolate(self.decoder3(
            t), size=down1.shape[-3:], mode='trilinear', align_corners=True))

        t = up3 + down1
        up4 = F.relu(F.interpolate(self.decoder4(
            t),  size=x.shape[-3:], mode='trilinear', align_corners=True))

        # t = down5 + down4
        # up1 = F.leaky_relu(F.interpolate(self.decoder1(t),
        #                                  size=down3.shape[-3:]))
        # t = up1 + down3
        # up2 = F.leaky_relu(F.interpolate(self.decoder2(t),
        #                                  size=down2.shape[-3:]))
        # t = up2 + down2
        # up3 = F.leaky_relu(F.interpolate(self.decoder3(t),
        #                                  size=down1.shape[-3:]))
        # t = up3 + down1
        # up4 = F.leaky_relu(F.interpolate(self.decoder4(t),
        #                                  size=x.shape[-3:]))

        if self.training is True:  # 从高分辨率依次降低
            return [
                F.interpolate(self.unres4(up4), size=x.shape[-3:]),
                F.interpolate(self.unres3(up3), size=x.shape[-3:]),
                F.interpolate(self.unres2(up2), size=x.shape[-3:]),
                F.interpolate(self.unres1(up1), size=x.shape[-3:])
            ]
        else:
            return F.interpolate(self.unres4(up4), size=x.shape[-3:])
