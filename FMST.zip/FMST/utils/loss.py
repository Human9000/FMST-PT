import torch
import torch.nn as nn
from torch.nn import functional as F


class DiceLoss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, pred, target):
        smooth = 1
        dice = 0.
        # dice系数的定义
        for i in range(pred.size(1)):
            # 2 * p * t/ ( p*p + t*t + 1 )
            dice += 2 * (pred[:, i] * target[:, i]).sum(dim=1).sum(dim=1).sum(dim=1) / (pred[:, i].pow(2).sum(dim=1).sum(dim=1).sum(dim=1) +
                                                                                        target[:, i].pow(2).sum(dim=1).sum(dim=1).sum(dim=1) + smooth)

        # 返回的是dice距离
        dice = dice / pred.size(1)
        return torch.clamp((1 - dice).mean(), 0, 1)


class JaccardLoss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, pred, target):

        smooth = 1

        # jaccard系数的定义
        jaccard = 0.

        for i in range(pred.size(1)):
            jaccard += (pred[:, i] * target[:, i]).sum(dim=1).sum(dim=1).sum(dim=1) / (pred[:, i].pow(2).sum(dim=1).sum(dim=1).sum(dim=1) +
                                                                                       target[:, i].pow(2).sum(dim=1).sum(dim=1).sum(dim=1) - (pred[:, i] * target[:, i]).sum(dim=1).sum(dim=1).sum(dim=1) + smooth)

        # 返回的是jaccard距离
        jaccard = jaccard / pred.size(1)
        return torch.clamp((1 - jaccard).mean(), 0, 1)


class TverskyLoss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, pred, target):
        smooth = 1
        dice = 0.

        def like(a, b):
            return (a * b).sum(dim=1).sum(dim=1).sum(dim=1)

        for i in range(pred.size(1)):
            # 内部准确率
            dice += like(pred[:, i], target[:, i]) / (like(pred[:, i], target[:, i]) +
                                                      0.3 * like(pred[:, i], (1 - target[:, i])) +
                                                      0.7 * like((1 - pred[:, i]), target[:, i]) + smooth)

        dice = dice / pred.size(1)

        return torch.clamp((1 - dice).mean(), 0, 2)



class AttnLoss(nn.Module):
    def __init__(self, r1=0.1, r5=1):
        super().__init__()
        self.r1 = r1
        self.r5 = r5

    def forward(self, pred, target):
        
        # 三维立方体波损失
        b = torch.abs(pred[:,0] - target[:,0]).mean() * 0.2 * 0.2
        f = torch.abs(pred[:,1:] - target[:,1:]).mean() * 0.8 * 0.2
        l1 = b+f
        
        # 二维矩阵波损失
        l2 = 0
        for dim in [2, 3, 4]:
            ps = 1.0 * (torch.sum(pred, dim=dim) > 0.1)
            ts = 1.0 * (torch.sum(target, dim=dim) > 0.1)
            b = torch.abs(ps[:,0] - ts[:,0]).mean() * 0.2 * 0.2
            f = torch.abs(ps[:,1:] - ts[:,1:]).mean() * 0.8 * 0.2
            l2 += b+f
            
        #  二维线性波损失
        l3 = 0
        for dim in [[2, 3],
                    [3, 4], 
                    [2, 4],]:
            ps = 1.0 * (torch.sum(pred, dim=dim) > 0.1)
            ts = 1.0 * (torch.sum(target, dim=dim) > 0.1)
            b = torch.abs(ps[:,0] - ts[:,0]).mean() * 0.2 * 0.2
            f = torch.abs(ps[:,1:] - ts[:,1:]).mean() * 0.8 * 0.2
            l3 += b+f
            
        #  零维点性波损失
        ps = 1.0 * (torch.sum(pred, dim=[2,3,4]) > 0.1)
        ts = 1.0 * (torch.sum(target, dim=[2,3,4]) > 0.1)
        b = torch.abs(ps[:,0] - ts[:,0]).mean() * 0.2 * 0.2
        f = torch.abs(ps[:,1:] - ts[:,1:]).mean() * 0.8 * 0.2
        l4 = b+f
        # l4 = torch.abs(ps - ts).mean()

        dice = 0
        # 内部像素
        for i in range(1, pred.size(1)):
            pi = pred[:, i]
            ti = target[:, i]
            inter = (pi * ti).sum(dim=[1, 2, 3])
            
            uninter1 = (pi + ti).sum(dim=[1, 2, 3])
            uninter2 = (pi**2 + ti**2).sum(dim=[1, 2, 3]) 
            uninter3 = (1-((1-pi) * (1-ti))).sum(dim=[1, 2, 3])
            
            dice +=  (1 + inter)/(1 + uninter2) + 0.5 * (1 + inter)/(1 + uninter3)
            
        l5 = ( - dice / pred.size(1)).mean()
        
        
        # # 最大边缘平面距离损失
        # dt = 8 # 极限边缘距离为8
        # lpt = F.max_pool3d(target, 3, 1, 1) - target # 真实边界
        # # lpt = F.interpolate(lpt, (32,32,32))
        
        # for _ in range(8):
        #     lpt = F.max_pool3d(lpt, 3, 1, 1) # 第 i 个边界
        #     dt -= lpt
        
        # # dt = F.interpolate(dt, target.shape[-3:], mode='trilinear', align_corners=True)    
        
        # # lpp = F.max_pool3d(pred, 3, 1, 1) - pred # 预测边界
        
        # # for _ in range(8):
        # #     lpt = F.max_pool3d(lpt, 3, 1, 1) # 第 i 个边界
        # #     dt -= lpt
        # dt[target>0.5] = 0
        # l3 = (dt * pred).mean()
        
        return self.r1*l1 + self.r5*l5

class Ourloss(nn.Module):
    def __init__(self, r1=0.3, r2=0.7):
        super().__init__()
        self.r1 = r1
        self.r2 = r2

    def forward(self, pred, target):

        criterion_y_x_1 = F.binary_cross_entropy(pred[:, 1:], target[:, 1:], reduction='mean')
        criterion_y_x_2 = F.binary_cross_entropy(pred[:, 1:], target[:, :1], reduction='mean')
        l1 = criterion_y_x_1 + criterion_y_x_2
        # y的背景
        criterion_y_x_1 = F.binary_cross_entropy(pred[:, :1], target[:, :1], reduction='mean')
        criterion_y_x_2 = F.binary_cross_entropy(pred[:, :1], target[:, 1:], reduction='mean')
        l2 = criterion_y_x_1 + criterion_y_x_2
        # loss
        loss = (self.r1 * l1 + self.r2 * l2) / 2
        # print('loss：', loss)
        return loss

