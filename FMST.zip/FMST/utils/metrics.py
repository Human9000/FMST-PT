import torch
import numpy as np
from medpy import metric


class LossAverage(object):
    """Computes and stores the average and current value for calculate average loss"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = round(self.sum / self.count, 4)


class BaseAverage(object):
    def __init__(self, class_num=2):
        self.class_num = class_num
        self.reset()

    def reset(self):
        self.value = np.asarray([0]*self.class_num, dtype='float64')
        self.avg = np.asarray([0]*self.class_num, dtype='float64')
        self.sum = np.asarray([0]*self.class_num, dtype='float64')
        self.count = 0

    def update(self, logits, targets):
        self.value = self.get_scores(logits, targets)
        self.sum += self.value
        self.count += 1
        self.avg = np.around(self.sum / self.count, 4)

    @staticmethod
    def get_scores(logits, targets):
        scores = []
        for class_index in range(targets.shape[1]):
            pi = logits[:, class_index]
            ti = targets[:, class_index]

            inter = torch.sum(pi * ti)
            uninter = torch.sum(pi*pi) + torch.sum(ti*ti)

            dice = (1 + 2 * inter) / (1 + uninter)

            scores.append(dice.item())
        return np.asarray(scores)


class Dice(BaseAverage):
    def __init__(self, class_num=2):
        super().__init__(class_num=class_num)

    @staticmethod
    def get_scores(logits, targets):
        scores = [0]
        for class_index in range(targets.shape[1]):
            if class_index == 0: continue
            pi = logits[:, class_index]
            ti = targets[:, class_index]

            inter = torch.sum(pi * ti)
            uninter = torch.sum(pi*pi) + torch.sum(ti*ti)

            dice = (1 + 2 * inter) / (1 + uninter)

            scores.append(dice.item())
        return np.asarray(scores)


class Dice2(BaseAverage):
    def __init__(self, class_num=2):
        super().__init__(class_num=class_num)

    @staticmethod
    def get_scores(logits, targets):
        scores = [0]
        for class_index in range(targets.shape[1]):
            if class_index == 0: continue
            b_score = []
            for b in range(targets.shape[0]):
                pi = logits[b, class_index]
                ti = targets[b, class_index]
                b_score.append(metric.binary.dc(pi, ti))
            scores.append(np.mean(b_score).item())
        return np.asarray(scores)


class Jaccard(BaseAverage):
    def __init__(self, class_num=2):
        super().__init__(class_num=class_num)

    @staticmethod
    def get_scores(logits, targets):
        scores = [0]
        for class_index in range(targets.shape[1]):
            if class_index == 0: continue
            pi = logits[:, class_index] > 0.1
            ti = targets[:, class_index] > 0.1

            inter = torch.sum(pi * ti)
            uninter = torch.sum(~((~pi) * (~ti)))

            score = (1 + inter) / (1 + uninter)

            scores.append(score.item())
        return np.asarray(scores)


class VOE(BaseAverage):
    def __init__(self, class_num=2):
        super().__init__(class_num=class_num)

    @staticmethod
    def get_scores(logits, targets):
        scores = [0]
        # s = 0
        # n = 0
        for class_index in range(targets.shape[1]):
            if class_index == 0: continue
            pi = logits[:, class_index] 
            ti = targets[:, class_index] 

            inter = torch.sum(pi * ti)
            uninter = torch.sum(1-((1-pi) * (1-ti)))

            score = 1 - (1 + inter) / (1 + uninter)
            
            # s+=0
            scores.append(score.item())
        return np.asarray(scores)


class RVD(BaseAverage):
    def __init__(self, class_num=2):
        super().__init__(class_num=class_num)

    @staticmethod
    def get_scores(logits, targets):
        scores = [0]
        for class_index in range(targets.shape[1]):
            if class_index == 0: continue
            pi = logits[:, class_index]
            ti = targets[:, class_index]

            inter = torch.sum(pi - ti)
            uninter = torch.sum(ti)

            score = (1 + inter) / (1 + uninter)

            scores.append(score.item())
        return np.asarray(scores)


class FNR(BaseAverage):
    def __init__(self, class_num=2):
        super().__init__(class_num=class_num)

    @staticmethod
    def get_scores(logits, targets):
        scores = [0]
        for class_index in range(targets.shape[1]):
            if class_index == 0: continue
            pi = logits[:, class_index]
            ti = targets[:, class_index]

            FN = (ti == 1) * (pi == 0)  # 原本是正类被预测成负类
            inter = torch.sum(FN)
            uninter = torch.sum(~((~pi) * (~ti)))

            score = 1 - (1 + inter) / (1 + uninter)

            scores.append(score.item())
        return np.asarray(scores)


class FPR(BaseAverage):
    def __init__(self, class_num=2):
        super().__init__(class_num=class_num)

    @staticmethod
    def get_scores(logits, targets):
        scores = [0]
        for class_index in range(targets.shape[1]):
            if class_index == 0: continue
            pi = logits[:, class_index]
            ti = targets[:, class_index]

            FP = (ti == 0) * (pi == 1)  # 原本是负类被预测成正类
            inter = torch.sum(FP)
            uninter = torch.sum(~((~pi) * (~ti)))

            score = (1 + inter) / (1 + uninter)

            scores.append(score.item())
        return np.asarray(scores)


class MSD(BaseAverage):
    def __init__(self, class_num=2):
        super().__init__(class_num=class_num)

    @staticmethod
    def get_scores(logits, targets):
        scores = [0]
        # s = 0
        for class_index in range(targets.shape[1]):
            if class_index == 0: continue
            b_score = []
            for b in range(targets.shape[0]):
                pi = logits[b, class_index].cpu().detach().numpy()> 0.1
                ti = targets[b, class_index].cpu().detach().numpy()> 0.1
                # print('---------------------', metric.binary.hd(pi, ti, voxelspacing=(0.6*2,0.6*2,0.6*2)))
                b_score.append(metric.binary.hd(pi, ti, voxelspacing=(0.6*2,0.6*2,0.6*2)))
            # s += np.mean(b_score).item()
            scores.append(np.mean(b_score).item())
        return np.asarray(scores)


surface_distances = metric.binary.__surface_distances


class RMSD(BaseAverage):
    def __init__(self, class_num=2):
        super().__init__(class_num=class_num)

    @staticmethod
    def get_scores(logits, targets):
        scores = [0]
        # s = 0
        for class_index in range(targets.shape[1]):
            if class_index == 0: continue
            b_score = []
            for b in range(targets.shape[0]):
                pi = logits[b, class_index].cpu().detach().numpy()> 0.1
                ti = targets[b, class_index].cpu().detach().numpy()> 0.1
                sds1 = surface_distances(ti, pi, voxelspacing=(0.6*2,0.6*2,0.6*2))
                sds2 = surface_distances(pi, ti, voxelspacing=(0.6*2,0.6*2,0.6*2))
                score = np.sqrt(
                    np.mean(np.concatenate((sds1*sds1, sds2*sds2))))
                b_score.append(score)
            # s += np.mean(b_score).item()
            scores.append(np.mean(b_score).item())
        return np.asarray(scores)


class ASSD(BaseAverage):
    def __init__(self, class_num=2):
        super().__init__(class_num=class_num)

    @staticmethod
    def get_scores(logits, targets):
        scores = [0]
        s = 0
        for class_index in range(targets.shape[1]):
            if class_index == 0: continue
            b_score = []
            for b in range(targets.shape[0]):
                pi = logits[b, class_index].cpu().detach().numpy()> 0.1
                ti = targets[b, class_index].cpu().detach().numpy()> 0.1
                b_score.append(metric.binary.assd(pi, ti,voxelspacing=(0.6*2,0.6*2,0.6*2)))
            
            # s += np.mean(b_score).item()
            scores.append(np.mean(b_score).item())
        return np.asarray(scores)


# class DiceAverage(object):
#     """Computes and stores the average and current value for calculate average loss"""

#     def __init__(self, class_num=2):
#         self.class_num = class_num
#         self.reset()

#     def reset(self):
#         self.value = np.asarray([0]*self.class_num, dtype='float64')
#         self.avg = np.asarray([0]*self.class_num, dtype='float64')
#         self.sum = np.asarray([0]*self.class_num, dtype='float64')
#         self.count = 0

#     def update(self, logits, targets):
#         self.value = DiceAverage.get_dices(logits, targets)
#         self.sum += self.value
#         self.count += 1
#         self.avg = np.around(self.sum / self.count, 4)

#     @staticmethod
#     def get_dices(logits, targets):
#         dices = []
#         for class_index in range(targets.shape[1]):
#             pi = logits[:, class_index]
#             ti = targets[:, class_index]

#             inter = torch.sum(pi * ti)
#             uninter = torch.sum(pi*pi) + torch.sum(ti*ti)

#             dice = (1 + 2 * inter) / (1 + uninter)

#             dices.append(dice.item())
#         return np.asarray(dices)


# class AttnDiceAverage(object):
#     """Computes and stores the average and current value for calculate average loss"""

#     def __init__(self, class_num=2):
#         self.class_num = class_num
#         self.reset()

#     def reset(self):
#         self.value = np.asarray([0]*self.class_num, dtype='float64')
#         self.avg = np.asarray([0]*self.class_num, dtype='float64')
#         self.sum = np.asarray([0]*self.class_num, dtype='float64')
#         self.count = 0

#     def update(self, logits, targets):
#         self.value = AttnDiceAverage.get_dices(logits, targets)
#         self.sum += self.value
#         self.count += 1
#         self.avg = np.around(self.sum / self.count, 4)

#     @staticmethod
#     def get_dices(logits, targets):
#         dices = []
#         for class_index in range(targets.shape[1]):
#             pi = logits[:, class_index]
#             ti = targets[:, class_index]
#             inter = torch.sum(pi * ti)
#             uninter = torch.sum(pi**2) + torch.sum(ti**2)
#             dice = (1 + 2 * inter) / (1 + uninter)

#             dices.append(dice.item())
#         return np.asarray(dices)

